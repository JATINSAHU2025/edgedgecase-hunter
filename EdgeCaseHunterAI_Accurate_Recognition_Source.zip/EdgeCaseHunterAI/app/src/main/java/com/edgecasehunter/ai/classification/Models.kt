package com.edgecasehunter.ai.classification

data class ScoredLabel(
    val rank: Int,
    val index: Int,
    val label: String,
    val modelScore: Float
)

data class CatalogMatch(
    val productId: String,
    val sku: String,
    val name: String,
    val category: String,
    val brand: String,
    val dimensions: String,
    val price: String,
    /** Raw cosine similarity, not a calibrated probability. */
    val similarity: Float
)

data class ClassificationResult(
    val topPredictions: List<ScoredLabel>,
    val inferenceTimeMs: Long,
    val source: ResultSource,
    val modelName: String,
    val modelRevision: String,
    val inputWidth: Int,
    val inputHeight: Int,
    val outputLength: Int,
    /** Optional natural-language details from an online vision-language model. */
    val description: String? = null,
    val visibleFeatures: List<String> = emptyList(),
    /** Qualitative uncertainty only; this is not a calibrated probability. */
    val uncertainty: String? = null,
    val detectedText: String? = null,
    val catalogMatches: List<CatalogMatch> = emptyList()
)

enum class ResultSource {
    ON_DEVICE,
    ONLINE
}

data class CropRect(
    val left: Int,
    val top: Int,
    val size: Int
)

sealed class ClassifierException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    class UnsupportedImage(message: String, cause: Throwable? = null) : ClassifierException(message, cause)
    class InferenceFailed(message: String, cause: Throwable? = null) : ClassifierException(message, cause)
    class ModelLoadFailed(message: String, cause: Throwable? = null) : ClassifierException(message, cause)
    class OnlineNotConfigured : ClassifierException("Online classification is not configured.")
    class OnlineFailed(message: String, cause: Throwable? = null) : ClassifierException(message, cause)
}
