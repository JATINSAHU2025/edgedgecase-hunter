package com.edgecasehunter.ai.classification

object ImageBytes {
    private val JPEG = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte())
    private val PNG = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
    private val WEBP_RIFF = byteArrayOf(0x52, 0x49, 0x46, 0x46)
    private val WEBP_WEBP = byteArrayOf(0x57, 0x45, 0x42, 0x50)

    fun validateHeader(bytes: ByteArray) {
        if (bytes.isEmpty()) {
            throw ClassifierException.UnsupportedImage("The selected file is empty.")
        }
        if (startsWith(bytes, JPEG)) return
        if (startsWith(bytes, PNG)) return
        if (bytes.size >= 12 && startsWith(bytes, WEBP_RIFF) &&
            bytes[8] == WEBP_WEBP[0] && bytes[9] == WEBP_WEBP[1] &&
            bytes[10] == WEBP_WEBP[2] && bytes[11] == WEBP_WEBP[3]
        ) {
            return
        }
        throw ClassifierException.UnsupportedImage(
            "Unsupported or corrupt image. Use a JPEG, PNG, or WebP photo."
        )
    }

    private fun startsWith(bytes: ByteArray, prefix: ByteArray): Boolean {
        if (bytes.size < prefix.size) return false
        for (i in prefix.indices) {
            if (bytes[i] != prefix[i]) return false
        }
        return true
    }
}
