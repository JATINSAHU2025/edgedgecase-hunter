package com.edgecasehunter.ai.classification

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class LabelMapperTest {
    private val bundledLabels: List<String> by lazy {
        val stream = requireNotNull(javaClass.classLoader?.getResourceAsStream("imagenet_labels.txt")) {
            "imagenet_labels.txt missing from test resources"
        }
        LabelMapper.loadLabels(stream.bufferedReader().readText())
    }

    @Test
    fun bundledLabels_areImageNet1K() {
        assertEquals(1000, bundledLabels.size)
        assertEquals("tench", bundledLabels.first())
        assertEquals("goldfish", bundledLabels[1])
        assertEquals("toilet tissue", bundledLabels.last())
    }

    @Test
    fun topK_sortsDescendingAndMapsIndices() {
        val labels = listOf("alpha", "beta", "gamma", "delta")
        val scores = floatArrayOf(0.05f, 0.40f, 0.10f, 0.45f)
        val top = LabelMapper.topK(scores, labels, k = 3)
        assertEquals(3, top.size)
        assertEquals("delta", top[0].label)
        assertEquals(3, top[0].index)
        assertEquals(0.45f, top[0].modelScore, 0.0001f)
        assertEquals("beta", top[1].label)
        assertEquals("gamma", top[2].label)
        assertEquals(1, top[0].rank)
    }

    @Test
    fun topK_rejectsMismatchedLengths() {
        assertThrows(IllegalArgumentException::class.java) {
            LabelMapper.topK(floatArrayOf(0.1f, 0.2f), listOf("only-one"), 1)
        }
    }

    @Test
    fun topK_rejectsNaN() {
        assertThrows(IllegalArgumentException::class.java) {
            LabelMapper.topK(floatArrayOf(0.1f, Float.NaN), listOf("a", "b"), 1)
        }
    }

    @Test
    fun topK_withBundledLabels_usesRealIndexMapping() {
        val scores = FloatArray(1000)
        scores[1] = 0.91f
        scores[0] = 0.05f
        scores[999] = 0.02f
        val top = LabelMapper.topK(scores, bundledLabels, k = 5)
        assertEquals("goldfish", top[0].label)
        assertEquals(1, top[0].index)
        assertTrue(top[0].modelScore > top[1].modelScore)
        assertEquals(5, top.size)
    }
}
