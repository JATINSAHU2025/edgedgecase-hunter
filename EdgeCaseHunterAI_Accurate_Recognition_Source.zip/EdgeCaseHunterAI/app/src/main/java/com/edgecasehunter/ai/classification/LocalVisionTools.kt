package com.edgecasehunter.ai.classification

import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Result of on-device OCR text extraction using ML Kit Latin model.
 */
data class TextRecognitionResult(
    val rawText: String,
    val lineCount: Int,
    val blockCount: Int,
    val inferenceTimeMs: Long
)

/**
 * Result of on-device Barcode / QR detection using ML Kit Barcode model.
 */
data class BarcodeScanResult(
    val displayValue: String,
    val rawValue: String,
    val formatName: String,
    val inferenceTimeMs: Long
)

/**
 * Executes local on-device OCR and Barcode recognition.
 * All processing is completely offline; no network calls are ever made.
 */
object LocalVisionTools {

    /**
     * Extracts Latin text from the provided image bitmap on background thread.
     */
    suspend fun recognizeText(bitmap: Bitmap): TextRecognitionResult = withContext(Dispatchers.Default) {
        val start = System.currentTimeMillis()
        val image = InputImage.fromBitmap(bitmap, 0)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

        try {
            val visionText = Tasks.await(recognizer.process(image))
            val elapsed = System.currentTimeMillis() - start
            val raw = visionText.text.trim()
            val blocks = visionText.textBlocks.size
            val lines = visionText.textBlocks.sumOf { it.lines.size }

            TextRecognitionResult(
                rawText = raw,
                lineCount = lines,
                blockCount = blocks,
                inferenceTimeMs = elapsed
            )
        } finally {
            recognizer.close()
        }
    }

    /**
     * Scans and decodes barcodes / QR codes from the provided image bitmap on background thread.
     */
    suspend fun scanBarcode(bitmap: Bitmap): BarcodeScanResult? = withContext(Dispatchers.Default) {
        val start = System.currentTimeMillis()
        val image = InputImage.fromBitmap(bitmap, 0)
        val scanner = BarcodeScanning.getClient()

        try {
            val barcodes = Tasks.await(scanner.process(image))
            val elapsed = System.currentTimeMillis() - start
            val first = barcodes.firstOrNull() ?: return@withContext null

            val formatStr = when (first.format) {
                Barcode.FORMAT_QR_CODE -> "QR Code"
                Barcode.FORMAT_EAN_13 -> "EAN-13"
                Barcode.FORMAT_EAN_8 -> "EAN-8"
                Barcode.FORMAT_UPC_A -> "UPC-A"
                Barcode.FORMAT_UPC_E -> "UPC-E"
                Barcode.FORMAT_CODE_128 -> "Code 128"
                Barcode.FORMAT_CODE_39 -> "Code 39"
                Barcode.FORMAT_DATA_MATRIX -> "Data Matrix"
                Barcode.FORMAT_AZTEC -> "Aztec"
                Barcode.FORMAT_PDF417 -> "PDF-417"
                else -> "Barcode"
            }

            BarcodeScanResult(
                displayValue = first.displayValue ?: first.rawValue.orEmpty(),
                rawValue = first.rawValue.orEmpty(),
                formatName = formatStr,
                inferenceTimeMs = elapsed
            )
        } finally {
            scanner.close()
        }
    }
}
