package com.edgecasehunter.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.edgecasehunter.ai.data.SavedScan
import com.edgecasehunter.ai.ui.camera.ScanMode
import com.edgecasehunter.ai.ui.components.AppSearchField
import com.edgecasehunter.ai.ui.components.EmptyStateView
import com.edgecasehunter.ai.ui.components.FilterChipItem
import com.edgecasehunter.ai.ui.components.ScanRowCard
import com.edgecasehunter.ai.ui.theme.AppColors

/**
 * 05 — Library Screen
 * Displays user's saved visual identifications with search, filter, and management actions.
 */
@Composable
fun LibraryScreen(
    savedScans: List<SavedScan>,
    onOpenScanDetail: (SavedScan) -> Unit,
    onDeleteScan: (String) -> Unit,
    onClearAll: () -> Unit,
    onStartScan: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") }
    var showClearConfirm by remember { mutableStateOf(false) }

    val filterOptions = listOf("All", "Objects", "Plants", "Animals", "Electronics", "Text", "Barcode")

    val filteredScans = savedScans.filter { scan ->
        val matchesCategory = selectedFilter == "All" || scan.category.equals(selectedFilter, ignoreCase = true)
        val matchesQuery = searchQuery.isBlank() ||
                scan.title.contains(searchQuery, ignoreCase = true) ||
                scan.category.contains(searchQuery, ignoreCase = true) ||
                (scan.extractedText?.contains(searchQuery, ignoreCase = true) == true) ||
                (scan.barcodeValue?.contains(searchQuery, ignoreCase = true) == true)
        matchesCategory && matchesQuery
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AppColors.Background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = "Saved Library",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = AppColors.TextPrimary
                )
                Text(
                    text = "${savedScans.size} ${if (savedScans.size == 1) "item" else "items"} saved on device",
                    fontSize = 12.sp,
                    color = AppColors.TextSecondary
                )
            }

            if (savedScans.isNotEmpty()) {
                IconButton(
                    onClick = { showClearConfirm = true },
                    modifier = Modifier.semantics { contentDescription = "Clear all saved scans" }
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = null,
                        tint = AppColors.Error
                    )
                }
            }
        }

        // Search Field
        AppSearchField(
            query = searchQuery,
            onQueryChange = { searchQuery = it },
            placeholder = "Search saved scans by name, text or category..."
        )

        // Filter Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            filterOptions.forEach { filter ->
                FilterChipItem(
                    label = filter,
                    isSelected = selectedFilter == filter,
                    onClick = { selectedFilter = filter }
                )
            }
        }

        // List or Empty State
        if (savedScans.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.BookmarkBorder,
                title = "No scans saved yet",
                message = "When you identify an object or text, tap 'Save' on the result screen to store it here locally.",
                actionText = "Start Scan",
                onActionClick = onStartScan
            )
        } else if (filteredScans.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.SearchOff,
                title = "No matching scans",
                message = "No saved records match your current filter or search query.",
                actionText = "Reset Search",
                onActionClick = {
                    searchQuery = ""
                    selectedFilter = "All"
                }
            )
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                filteredScans.forEach { scan ->
                    ScanRowCard(
                        scan = scan,
                        onClick = { onOpenScanDetail(scan) },
                        onDelete = { onDeleteScan(scan.id) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(60.dp))
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Clear Library History") },
            text = { Text("Are you sure you want to delete all saved scans and thumbnails from this device? This action cannot be undone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onClearAll()
                        showClearConfirm = false
                    }
                ) {
                    Text("Clear All", color = AppColors.Error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
