package com.edgecasehunter.ai.ui.navigation

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.edgecasehunter.ai.ui.theme.AppColors

enum class AppDestination(val title: String) {
    HOME("Home"),
    EXPLORE("Explore"),
    SCAN("Scan"),
    LIBRARY("Library"),
    TOOLS("Tools")
}

/**
 * Five-destination bottom navigation with a raised central camera action.
 *
 * The raised camera button is a sibling of the bar Surface, not a child of it.
 * This is important: Surface clips its content to its own bounds, so an offset
 * button placed inside a 72dp Surface could be clipped at the top. The outer
 * Box reserves enough height for the complete 60dp button and allows it to
 * overlap the bar without clipping. Navigation-bar insets are also respected.
 */
@Composable
fun AppBottomNavigation(
    currentDestination: AppDestination,
    onDestinationSelected: (AppDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .height(82.dp)
    ) {
        // The normal navigation strip starts 10dp below the raised scan button.
        Surface(
            color = AppColors.Surface,
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
            shadowElevation = 8.dp,
            border = BorderStroke(1.dp, AppColors.Border),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(72.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp)
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                NavItem(
                    title = AppDestination.HOME.title,
                    selected = currentDestination == AppDestination.HOME,
                    iconSelected = Icons.Filled.Home,
                    iconUnselected = Icons.Outlined.Home,
                    modifier = Modifier.weight(1f),
                    onClick = { onDestinationSelected(AppDestination.HOME) }
                )

                NavItem(
                    title = AppDestination.EXPLORE.title,
                    selected = currentDestination == AppDestination.EXPLORE,
                    iconSelected = Icons.Filled.Explore,
                    iconUnselected = Icons.Outlined.Explore,
                    modifier = Modifier.weight(1f),
                    onClick = { onDestinationSelected(AppDestination.EXPLORE) }
                )

                // Keep a full tab-width slot under the raised camera button.
                Box(modifier = Modifier.weight(1f).height(72.dp))

                NavItem(
                    title = AppDestination.LIBRARY.title,
                    selected = currentDestination == AppDestination.LIBRARY,
                    iconSelected = Icons.Filled.Bookmark,
                    iconUnselected = Icons.Outlined.BookmarkBorder,
                    modifier = Modifier.weight(1f),
                    onClick = { onDestinationSelected(AppDestination.LIBRARY) }
                )

                NavItem(
                    title = AppDestination.TOOLS.title,
                    selected = currentDestination == AppDestination.TOOLS,
                    iconSelected = Icons.Filled.Widgets,
                    iconUnselected = Icons.Outlined.Widgets,
                    modifier = Modifier.weight(1f),
                    onClick = { onDestinationSelected(AppDestination.TOOLS) }
                )
            }
        }

        // Draw above the Surface so no parent Surface can clip the circle/icon.
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .size(60.dp)
                .shadow(10.dp, CircleShape, spotColor = AppColors.Primary)
                .background(AppColors.Primary, CircleShape)
                .clickable { onDestinationSelected(AppDestination.SCAN) }
                .semantics { contentDescription = "Scan, open camera" },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.CameraAlt,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
private fun NavItem(
    title: String,
    selected: Boolean,
    iconSelected: ImageVector,
    iconUnselected: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 2.dp, vertical = 6.dp)
            .semantics {
                contentDescription = "$title tab, ${if (selected) "active" else "inactive"}"
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = if (selected) iconSelected else iconUnselected,
            contentDescription = null,
            tint = if (selected) AppColors.Primary else AppColors.TextSecondary,
            modifier = Modifier.size(24.dp)
        )
        Text(
            text = title,
            color = if (selected) AppColors.Primary else AppColors.TextSecondary,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1
        )
    }
}
