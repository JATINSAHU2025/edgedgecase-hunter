package com.edgecasehunter.ai.classification

import android.content.Context
import com.edgecasehunter.ai.BuildConfig

/** Stores only the user's backend URL and demo access token; never stores a provider API key. */
class OnlineConfigStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun endpoint(): String = prefs.getString(KEY_ENDPOINT, BuildConfig.ONLINE_CLASSIFIER_ENDPOINT).orEmpty()
    fun clientToken(): String = prefs.getString(KEY_TOKEN, BuildConfig.ONLINE_CLASSIFIER_CLIENT_TOKEN).orEmpty()

    fun save(endpoint: String, token: String) {
        prefs.edit()
            .putString(KEY_ENDPOINT, endpoint.trim())
            .putString(KEY_TOKEN, token.trim())
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "edgecase_online_config"
        private const val KEY_ENDPOINT = "endpoint"
        private const val KEY_TOKEN = "demo_client_token"
    }
}
