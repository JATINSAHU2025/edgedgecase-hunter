package com.edgecasehunter.ai.classification

import android.util.Base64
import android.os.SystemClock
import com.edgecasehunter.ai.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Optional remote vision-language classifier. The mobile app sends a compressed image
 * to the user's HTTPS backend; provider API credentials must stay on that backend.
 *
 * Backend request JSON: { "imageBase64": "...", "mimeType": "image/jpeg" }
 * Backend response JSON: {
 *   "name": "Brass ball valve",
 *   "description": "...",
 *   "visibleFeatures": ["..."],
 *   "alternatives": ["..."],
 *   "uncertainty": "medium",
 *   "detectedText": "...",
 *   "matches": [{"productId":"...", "sku":"...", "name":"...", "similarity":0.31}],
 *   "model": "MobileCLIP2-S2" or the configured server-side vision model
 * }
 */
interface OnlineImageClassifier {
    val isConfigured: Boolean
    suspend fun classify(imageBytes: ByteArray): ClassificationResult
}

class UnconfiguredOnlineImageClassifier : OnlineImageClassifier {
    override val isConfigured: Boolean = false

    override suspend fun classify(imageBytes: ByteArray): ClassificationResult {
        throw ClassifierException.OnlineNotConfigured()
    }
}

class HttpOnlineImageClassifier(
    private val endpoint: String = BuildConfig.ONLINE_CLASSIFIER_ENDPOINT,
    private val clientToken: String = BuildConfig.ONLINE_CLASSIFIER_CLIENT_TOKEN
) : OnlineImageClassifier {

    override val isConfigured: Boolean
        get() = endpointIsValid(endpoint) && clientToken.isNotBlank()

    /** Calls the backend's authenticated /health endpoint to expose connection setup errors. */
    suspend fun checkConnection(): String = withContext(Dispatchers.IO) {
        if (!endpointIsValid(endpoint)) throw ClassifierException.OnlineNotConfigured()
        val endpointUrl = URL(endpoint)
        val parentPath = endpointUrl.path.substringBeforeLast("/", "").trimEnd('/')
        val healthPath = "$parentPath/health".ifBlank { "/health" }
        val healthUrl = URL(endpointUrl.protocol, endpointUrl.host, endpointUrl.port, healthPath)
        val connection = (healthUrl.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = 10_000
            useCaches = false
            setRequestProperty("Accept", "application/json")
            if (clientToken.isNotBlank()) setRequestProperty("Authorization", "Bearer $clientToken")
        }
        try {
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.use { readLimited(it, 128 * 1024) }.orEmpty()
            if (status !in 200..299) {
                throw ClassifierException.OnlineFailed(
                    when (status) {
                        401, 403 -> "Backend rejected the demo access token. Check the token in Settings."
                        404 -> "Backend /health endpoint was not found. Check the endpoint URL."
                        503 -> "Backend is deployed but its model or access token is not configured correctly."
                        else -> "Backend health check returned HTTP $status."
                    }
                )
            }
            val health = JSONObject(body)
            if (!health.optBoolean("providerConfigured", false)) {
                throw ClassifierException.OnlineFailed("Backend is reachable, but its vision model provider is not configured.")
            }
            if (!health.optBoolean("accessTokenConfigured", false)) {
                throw ClassifierException.OnlineFailed("Backend is reachable, but its access token is not configured.")
            }
            "Connection successful · ${health.optString("model", "vision model")} is configured."
        } catch (e: ClassifierException) {
            throw e
        } catch (e: java.net.SocketTimeoutException) {
            throw ClassifierException.OnlineFailed("Backend health check timed out. Check the service URL and internet connection.", e)
        } catch (e: java.net.UnknownHostException) {
            throw ClassifierException.OnlineFailed("Cannot resolve the backend host. Check the URL and internet connection.", e)
        } catch (e: IOException) {
            throw ClassifierException.OnlineFailed("Could not reach the backend: ${e.message ?: "network error"}", e)
        } catch (e: Exception) {
            throw ClassifierException.OnlineFailed("Backend health check returned an invalid response.", e)
        } finally {
            connection.disconnect()
        }
    }

    override suspend fun classify(imageBytes: ByteArray): ClassificationResult = withContext(Dispatchers.IO) {
        if (!isConfigured) throw ClassifierException.OnlineNotConfigured()
        if (imageBytes.isEmpty()) throw ClassifierException.OnlineFailed("The captured image is empty.")
        if (imageBytes.size > MAX_UPLOAD_BYTES) {
            throw ClassifierException.OnlineFailed("The image is too large to send. Try a smaller or tighter photo.")
        }

        val requestStarted = SystemClock.elapsedRealtime()
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            doOutput = true
            doInput = true
            useCaches = false
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Connection", "close")
            if (clientToken.isNotBlank()) setRequestProperty("Authorization", "Bearer $clientToken")
        }

        try {
            val request = JSONObject()
                .put("imageBase64", Base64.encodeToString(imageBytes, Base64.NO_WRAP))
                .put("mimeType", "image/jpeg")
                .toString()
                .toByteArray(Charsets.UTF_8)

            connection.outputStream.use { stream -> stream.write(request) }
            val status = connection.responseCode
            val responseStream = if (status in 200..299) connection.inputStream else connection.errorStream
            val responseBody = responseStream?.use { readLimited(it, MAX_RESPONSE_BYTES) }.orEmpty()
            if (status !in 200..299) {
                val serverMessage = runCatching {
                    JSONObject(responseBody).optString("detail").ifBlank {
                        JSONObject(responseBody).optString("error")
                    }
                }.getOrNull().orEmpty()
                throw ClassifierException.OnlineFailed(
                    when (status) {
                        401, 403 -> "Online service rejected access. Check backend authentication/configuration."
                        404 -> "Online endpoint was not found. Check the configured /classify URL."
                        413 -> "Online service rejected the image because it is too large."
                        429 -> "Online service rate limit reached. Wait a moment and retry."
                        in 500..599 -> "Online vision service is temporarily unavailable. Try again later."
                        else -> serverMessage.ifBlank { "Online service returned HTTP $status." }
                    }
                )
            }
            parseResponse(responseBody, SystemClock.elapsedRealtime() - requestStarted)
        } catch (e: ClassifierException) {
            throw e
        } catch (e: java.net.SocketTimeoutException) {
            throw ClassifierException.OnlineFailed("Online identification timed out. Try again on a more stable connection.", e)
        } catch (e: java.net.UnknownHostException) {
            throw ClassifierException.OnlineFailed("Cannot reach the online service. Check internet access and the backend URL.", e)
        } catch (e: javax.net.ssl.SSLException) {
            throw ClassifierException.OnlineFailed("Secure connection to the online service failed. Check its HTTPS certificate.", e)
        } catch (e: IOException) {
            throw ClassifierException.OnlineFailed("Could not connect to the online service: ${e.message ?: "network error"}", e)
        } catch (e: Exception) {
            throw ClassifierException.OnlineFailed("Online service returned an invalid response.", e)
        } finally {
            connection.disconnect()
        }
    }

    private fun parseResponse(body: String, elapsedMs: Long): ClassificationResult {
        if (body.isBlank()) throw ClassifierException.OnlineFailed("Online service returned an empty response.")
        val json = try {
            JSONObject(body)
        } catch (e: Exception) {
            throw ClassifierException.OnlineFailed("Online service response was not valid JSON.", e)
        }
        val name = json.optString("name").trim()
        if (name.isBlank() || name.equals("null", ignoreCase = true)) {
            throw ClassifierException.OnlineFailed("Online model did not return an object name. Try a clearer, closer photo.")
        }

        val alternatives = json.optJSONArray("alternatives").toStringList()
            .filter { it.isNotBlank() && !it.equals(name, ignoreCase = true) }
            .distinctBy { it.lowercase() }
            .take(MAX_ALTERNATIVES)
        val predictions = buildList {
            add(ScoredLabel(rank = 1, index = -1, label = name, modelScore = 0f))
            alternatives.forEachIndexed { index, label ->
                add(ScoredLabel(rank = index + 2, index = -1, label = label, modelScore = 0f))
            }
        }

        val catalogMatches = json.optJSONArray("matches").let { array ->
            if (array == null) emptyList() else buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val matchName = item.optString("name").trim()
                    if (matchName.isBlank()) continue
                    add(CatalogMatch(
                        productId = item.optString("productId"),
                        sku = item.optString("sku"),
                        name = matchName,
                        category = item.optString("category"),
                        brand = item.optString("brand"),
                        dimensions = item.optString("dimensions"),
                        price = item.optString("price"),
                        similarity = item.optDouble("similarity", 0.0).toFloat()
                    ))
                }
            }
        }

        return ClassificationResult(
            topPredictions = predictions,
            inferenceTimeMs = elapsedMs,
            source = ResultSource.ONLINE,
            modelName = json.optString("model").ifBlank { "Online vision-language model" },
            modelRevision = json.optString("modelVersion").ifBlank { "remote" },
            inputWidth = 0,
            inputHeight = 0,
            outputLength = predictions.size,
            description = json.optString("description").takeIf { it.isNotBlank() && it != "null" },
            visibleFeatures = json.optJSONArray("visibleFeatures").toStringList().take(8),
            uncertainty = json.optString("uncertainty").takeIf { it.isNotBlank() && it != "null" },
            detectedText = json.optString("detectedText").takeIf { it.isNotBlank() && it != "null" },
            catalogMatches = catalogMatches
        )
    }

    private fun JSONArray?.toStringList(): List<String> {
        if (this == null) return emptyList()
        return buildList {
            for (index in 0 until length()) {
                val value = opt(index)
                if (value is String && value.isNotBlank()) add(value.trim())
                else if (value is JSONObject) {
                    val label = value.optString("name").ifBlank { value.optString("label") }
                    if (label.isNotBlank()) add(label.trim())
                }
            }
        }
    }

    private fun readLimited(input: java.io.InputStream, maxBytes: Int): String {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8 * 1024)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            if (total > maxBytes) throw IOException("Server response exceeded the size limit.")
            output.write(buffer, 0, count)
        }
        return output.toString(Charsets.UTF_8.name())
    }

    private fun endpointIsValid(endpoint: String): Boolean = try {
        val url = URL(endpoint)
        url.protocol.equals("https", ignoreCase = true) && !url.host.isNullOrBlank()
    } catch (_: Exception) {
        false
    }

    companion object {
        private const val CONNECT_TIMEOUT_MS = 12_000
        private const val READ_TIMEOUT_MS = 120_000
        private const val MAX_UPLOAD_BYTES = 6 * 1024 * 1024
        private const val MAX_RESPONSE_BYTES = 1 * 1024 * 1024
        private const val MAX_ALTERNATIVES = 4
    }
}
