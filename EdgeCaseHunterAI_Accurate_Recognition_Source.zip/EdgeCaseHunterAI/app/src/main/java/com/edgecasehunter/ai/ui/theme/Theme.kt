package com.edgecasehunter.ai.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColors = darkColorScheme(
    primary = AppColors.Primary,
    onPrimary = Color.White,
    primaryContainer = AppColors.PrimarySubtle,
    onPrimaryContainer = AppColors.PrimaryPressed,
    background = Color(0xFF101B2B),
    onBackground = Color(0xFFF4F7FC),
    surface = Color(0xFF17253A),
    onSurface = Color(0xFFF4F7FC),
    surfaceVariant = Color(0xFF1F3048),
    onSurfaceVariant = AppColors.TextSecondary,
    outline = Color(0xFF2E4057),
    error = AppColors.Error
)

private val LightColors = lightColorScheme(
    primary = AppColors.Primary,
    onPrimary = Color.White,
    primaryContainer = AppColors.PrimarySubtle,
    onPrimaryContainer = AppColors.PrimaryPressed,
    background = AppColors.Background,
    onBackground = AppColors.TextPrimary,
    surface = AppColors.Surface,
    onSurface = AppColors.TextPrimary,
    surfaceVariant = AppColors.SurfaceSubtle,
    onSurfaceVariant = AppColors.TextSecondary,
    outline = AppColors.Border,
    error = AppColors.Error
)

/**
 * Tokenized Jetpack Compose theme for EdgeCase Hunter AI.
 * Light mode is the default experience as defined in DESIGN_TOKENS.json.
 */
@Composable
fun EdgeCaseHunterTheme(
    darkTheme: Boolean = false, // Light mode by default per design tokens specification
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        content = content
    )
}
