package com.edgecasehunter.ai.classification

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipFile

class ModelAssetVerificationTest {
    private val expectedSha256 = "AA03E4017F54FD5C743BD397B0A3E136FAB0942F9C7CD715064A31CA3E4FC996"

    @Test
    fun bundledModel_isGenuineTfliteWithImageNetLabels() {
        val model = locateModel()
        assertTrue("Model file must be non-empty", model.length() > 1_000_000)

        val header = model.inputStream().use { it.readNBytes(8) }
        val magic = String(header.copyOfRange(4, 8), Charsets.US_ASCII)
        assertEquals("TFL3", magic)

        val digest = MessageDigest.getInstance("SHA-256")
        model.inputStream().use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        val actual = digest.digest().joinToString("") { "%02X".format(it) }
        assertEquals(expectedSha256, actual)

        ZipFile(model).use { zip ->
            val entry = zip.getEntry("labels_without_background.txt")
            requireNotNull(entry) { "Model metadata must include labels_without_background.txt" }
            val labels = zip.getInputStream(entry).bufferedReader().readLines().filter { it.isNotBlank() }
            assertEquals(1000, labels.size)
            assertEquals("tench", labels.first())
            assertEquals("toilet tissue", labels.last())
        }
    }

    @Test
    fun offlineClassifierSource_doesNotOpenNetworkConnections() {
        val source = locateSource("OfflineImageClassifier.kt").readText()
        assertTrue(source.contains("ImageClassifier.createFromFileAndOptions"))
        assertTrue(!source.contains("java.net"))
        assertTrue(!source.contains("OkHttp"))
        assertTrue(!source.contains("HttpURLConnection"))
        assertTrue(!source.contains("openConnection"))
    }

    private fun locateModel(): File {
        val candidates = listOf(
            File("src/main/assets/models/efficientnet_lite0_int8_2.tflite"),
            File("app/src/main/assets/models/efficientnet_lite0_int8_2.tflite")
        )
        return candidates.first { it.isFile }
    }

    private fun locateSource(name: String): File {
        val candidates = listOf(
            File("src/main/java/com/edgecasehunter/ai/classification/$name"),
            File("app/src/main/java/com/edgecasehunter/ai/classification/$name")
        )
        return candidates.first { it.isFile }
    }
}
