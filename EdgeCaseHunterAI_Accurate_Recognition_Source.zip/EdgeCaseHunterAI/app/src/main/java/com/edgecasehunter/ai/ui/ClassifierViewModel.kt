package com.edgecasehunter.ai.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.edgecasehunter.ai.BuildConfig
import com.edgecasehunter.ai.classification.ClassificationResult
import com.edgecasehunter.ai.classification.ClassifierException
import com.edgecasehunter.ai.classification.LocalVisionTools
import com.edgecasehunter.ai.classification.HttpOnlineImageClassifier
import com.edgecasehunter.ai.classification.ImageUploadEncoder
import com.edgecasehunter.ai.classification.OnlineConfigStore
import com.edgecasehunter.ai.classification.OfflineImageClassifier
import com.edgecasehunter.ai.classification.OnlineImageClassifier
import com.edgecasehunter.ai.classification.SelectedImageDecoder
import com.edgecasehunter.ai.data.LibraryRepository
import com.edgecasehunter.ai.data.SavedScan
import com.edgecasehunter.ai.ui.camera.ScanMode
import com.edgecasehunter.ai.ui.navigation.AppDestination
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Screen presentation sub-states for capture review and results.
 */
enum class AppSubState {
    DEFAULT,
    REVIEW,
    RESULT
}

/**
 * Complete UI State for EdgeCase Hunter AI.
 */
data class ClassifierUiState(
    val currentDestination: AppDestination = AppDestination.HOME,
    val subState: AppSubState = AppSubState.DEFAULT,
    val scanMode: ScanMode = ScanMode.PHOTO,
    val preview: Bitmap? = null,
    val isLoading: Boolean = false,
    val loadingMessage: String = "",
    val result: ClassificationResult? = null,
    val extractedText: String? = null,
    val barcodeValue: String? = null,
    val isCurrentResultSaved: Boolean = false,
    val savedScans: List<SavedScan> = emptyList(),
    val errorMessage: String? = null,
    val showSettings: Boolean = false,
    val onlineConfigured: Boolean = BuildConfig.ONLINE_CLASSIFIER_ENABLED,
    val onlineEndpoint: String = BuildConfig.ONLINE_CLASSIFIER_ENDPOINT,
    val onlineClientToken: String = BuildConfig.ONLINE_CLASSIFIER_CLIENT_TOKEN,
    val isTestingOnlineConnection: Boolean = false,
    val onlineTestMessage: String? = null,
    val attemptOnline: Boolean = false,
    val homeSearchQuery: String = ""
)

/**
 * ViewModel managing the business logic, state machines, offline inference,
 * and local library persistence.
 */
class ClassifierViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = LibraryRepository(application)
    private val onlineConfigStore = OnlineConfigStore(application)
    private var online: HttpOnlineImageClassifier = HttpOnlineImageClassifier(
        endpoint = onlineConfigStore.endpoint(),
        clientToken = onlineConfigStore.clientToken()
    )
    private val classifierLock = Any()
    private var offline: OfflineImageClassifier? = null

    private val _state = MutableStateFlow(
        ClassifierUiState(
            onlineConfigured = online.isConfigured,
            onlineEndpoint = onlineConfigStore.endpoint(),
            onlineClientToken = onlineConfigStore.clientToken(),
            savedScans = repository.getAll()
        )
    )
    val state: StateFlow<ClassifierUiState> = _state

    /**
     * Switch bottom navigation destination.
     */
    fun selectDestination(destination: AppDestination) {
        _state.update {
            it.copy(
                currentDestination = destination,
                subState = AppSubState.DEFAULT,
                errorMessage = null
            )
        }
    }

    /**
     * Update active scanning mode.
     */
    fun setScanMode(mode: ScanMode) {
        _state.update { it.copy(scanMode = mode) }
    }

    /**
     * Handle image captured directly from CameraX viewfinder.
     */
    fun onImageCaptured(bitmap: Bitmap) {
        // Do not recycle the previous bitmap synchronously: Compose may still be drawing it.
        _state.update {
            it.copy(
                preview = bitmap,
                subState = AppSubState.REVIEW,
                result = null,
                extractedText = null,
                barcodeValue = null,
                errorMessage = null
            )
        }
    }

    /**
     * Handle image chosen via System Photo Picker.
     */
    fun onImagePicked(uri: Uri) {
        viewModelScope.launch {
            _state.update {
                it.copy(
                    isLoading = true,
                    loadingMessage = "Loading selected image...",
                    errorMessage = null
                )
            }
            try {
                val bitmap = withContext(Dispatchers.IO) {
                    SelectedImageDecoder.decode(getApplication(), uri)
                }
                // Let the replaced bitmap be reclaimed naturally after Compose releases it.
                _state.update {
                    it.copy(
                        preview = bitmap,
                        isLoading = false,
                        subState = AppSubState.REVIEW,
                        result = null,
                        extractedText = null,
                        barcodeValue = null
                    )
                }
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = userMessage(e)
                    )
                }
            }
        }
    }

    /**
     * Executes local inference, or sends a compressed image only when the user explicitly
     * enabled a configured online provider. Heavy work is kept off the main thread.
     */
    fun identify() {
        val current = _state.value
        if (current.isLoading) return
        val preview = current.preview ?: run {
            _state.update { it.copy(errorMessage = "Please capture or choose an image first.") }
            return
        }
        val modeAtStart = current.scanMode
        val onlineProvider = online // Snapshot configuration for the duration of this request.
        val useOnline = current.attemptOnline && modeAtStart in setOf(ScanMode.PHOTO, ScanMode.MULTI)
        if (useOnline && !onlineProvider.isConfigured) {
            _state.update { it.copy(errorMessage = "Online identification is not configured. Open Settings and enter your deployed HTTPS backend URL and access token.") }
            return
        }

        viewModelScope.launch {
            _state.update {
                it.copy(
                    isLoading = true,
                    loadingMessage = when {
                        useOnline -> "Sending this photo to your configured online vision service..."
                        modeAtStart == ScanMode.TEXT -> "Extracting text on this device..."
                        modeAtStart == ScanMode.BARCODE -> "Reading barcode / QR code on this device..."
                        else -> "Identifying objects on this device..."
                    },
                    errorMessage = null
                )
            }

            try {
                var classificationResult: ClassificationResult? = null
                var textResult: String? = null
                var barcodeResult: String? = null

                withContext(Dispatchers.Default) {
                    when (modeAtStart) {
                        ScanMode.TEXT -> {
                            val ocr = LocalVisionTools.recognizeText(preview)
                            textResult = ocr.rawText.ifBlank { "No readable text detected in this image." }
                        }
                        ScanMode.BARCODE -> {
                            val code = LocalVisionTools.scanBarcode(preview)
                            barcodeResult = code?.displayValue ?: "No barcode or QR symbol detected."
                        }
                        ScanMode.PHOTO, ScanMode.MULTI -> {
                            if (useOnline) {
                                // Image transfer occurs only after the user explicitly selected online mode.
                                val jpeg = ImageUploadEncoder.toJpegBytes(preview)
                                classificationResult = onlineProvider.classify(jpeg)
                                textResult = classificationResult?.detectedText
                            } else {
                                classificationResult = synchronized(classifierLock) {
                                    val classifier = offline ?: OfflineImageClassifier(getApplication()).also {
                                        offline = it
                                    }
                                    classifier.classify(preview)
                                }
                            }

                            // OCR adds useful clues (e.g. product labels) but is non-critical.
                            if (textResult.isNullOrBlank()) {
                                try {
                                    val ocr = LocalVisionTools.recognizeText(preview)
                                    if (ocr.rawText.isNotBlank()) textResult = ocr.rawText
                                } catch (_: Exception) {
                                    // Main identification result remains usable if OCR fails.
                                }
                            }
                        }
                    }
                }

                _state.update {
                    it.copy(
                        isLoading = false,
                        subState = AppSubState.RESULT,
                        result = classificationResult,
                        extractedText = textResult,
                        barcodeValue = barcodeResult,
                        isCurrentResultSaved = false
                    )
                }
            } catch (e: OutOfMemoryError) {
                _state.update {
                    it.copy(isLoading = false, errorMessage = "This photo exceeded available memory. Please choose a smaller image or close other apps and retry.")
                }
            } catch (e: Exception) {
                _state.update {
                    it.copy(isLoading = false, errorMessage = userMessage(e))
                }
            }
        }
    }

    /**
     * Toggles saving the current identification result into the local Library.
     */
    fun toggleSaveCurrentResult() {
        val currentState = _state.value
        val preview = currentState.preview

        if (currentState.isCurrentResultSaved) {
            // Already saved; let's keep it saved or delete
            return
        }

        val topPred = currentState.result?.topPredictions?.firstOrNull()
        val title = when {
            currentState.barcodeValue != null -> "Barcode: ${currentState.barcodeValue.take(20)}"
            currentState.extractedText?.isNotBlank() == true && currentState.result == null -> "Text: ${currentState.extractedText.take(25)}..."
            topPred != null -> topPred.label.replaceFirstChar { it.uppercase() }
            else -> "Saved Visual Scan"
        }

        val category = when (currentState.scanMode) {
            ScanMode.TEXT -> "Text"
            ScanMode.BARCODE -> "Barcode"
            ScanMode.MULTI -> "Objects"
            ScanMode.PHOTO -> "General"
        }

        val scan = SavedScan(
            title = title,
            category = category,
            source = when {
                currentState.barcodeValue != null -> "Barcode Scanner"
                currentState.extractedText != null && currentState.result == null -> "Text OCR"
                currentState.result?.source == com.edgecasehunter.ai.classification.ResultSource.ONLINE -> "Online Vision Model"
                else -> "On-Device Neural Model"
            },
            inferenceTimeMs = currentState.result?.inferenceTimeMs ?: 0L,
            confidence = topPred?.modelScore ?: 0f,
            extractedText = currentState.extractedText,
            barcodeValue = currentState.barcodeValue,
            alternativePredictions = currentState.result?.topPredictions.orEmpty()
        )

        viewModelScope.launch(Dispatchers.IO) {
            repository.save(scan, preview)
            val updated = repository.getAll()
            _state.update {
                it.copy(
                    isCurrentResultSaved = true,
                    savedScans = updated
                )
            }
        }
    }

    /**
     * Deletes a saved scan from library.
     */
    fun deleteSavedScan(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.delete(id)
            val updated = repository.getAll()
            _state.update { it.copy(savedScans = updated) }
        }
    }

    /**
     * Clears all saved scans and cached thumbnails.
     */
    fun clearAllSavedScans() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearAll()
            _state.update { it.copy(savedScans = emptyList()) }
        }
    }

    /**
     * Opens a saved scan from the Library to view its details.
     */
    fun openSavedScanDetail(scan: SavedScan) {
        _state.update {
            it.copy(
                subState = AppSubState.RESULT,
                extractedText = scan.extractedText,
                barcodeValue = scan.barcodeValue,
                isCurrentResultSaved = true,
                result = if (scan.alternativePredictions.isNotEmpty()) {
                    ClassificationResult(
                        topPredictions = scan.alternativePredictions,
                        inferenceTimeMs = scan.inferenceTimeMs,
                        source = com.edgecasehunter.ai.classification.ResultSource.ON_DEVICE,
                        modelName = BuildConfig.MODEL_DISPLAY_NAME,
                        modelRevision = BuildConfig.MODEL_REVISION,
                        inputWidth = BuildConfig.MODEL_INPUT_SIZE,
                        inputHeight = BuildConfig.MODEL_INPUT_SIZE,
                        outputLength = 1000
                    )
                } else null
            )
        }
    }

    /**
     * Resets the scan flow and returns to live camera.
     */
    fun scanAgain() {
        _state.update {
            it.copy(
                preview = null,
                subState = AppSubState.DEFAULT,
                currentDestination = AppDestination.SCAN,
                result = null,
                extractedText = null,
                barcodeValue = null,
                errorMessage = null
            )
        }
    }

    /**
     * Discards the capture review and returns to camera preview.
     */
    fun retakeCapture() {
        _state.update {
            it.copy(
                preview = null,
                subState = AppSubState.DEFAULT,
                errorMessage = null
            )
        }
    }

    fun toggleSettings(show: Boolean) {
        _state.update { it.copy(showSettings = show) }
    }

    fun setAttemptOnline(enabled: Boolean) {
        if (enabled && !online.isConfigured) {
            _state.update {
                it.copy(
                    attemptOnline = false,
                    errorMessage = "Online identification needs an HTTPS /classify endpoint and its backend access token. Configure these in Settings."
                )
            }
            return
        }
        _state.update { it.copy(attemptOnline = enabled) }
    }

    fun saveOnlineConfiguration(endpoint: String, token: String) {
        val cleanEndpoint = endpoint.trim().trimEnd('/')
        val normalizedEndpoint = if (cleanEndpoint.endsWith("/classify", ignoreCase = true)) {
            cleanEndpoint
        } else if (cleanEndpoint.isNotBlank()) {
            "$cleanEndpoint/classify"
        } else ""
        onlineConfigStore.save(normalizedEndpoint, token)
        online = HttpOnlineImageClassifier(normalizedEndpoint, token.trim())
        _state.update {
            it.copy(
                onlineEndpoint = normalizedEndpoint,
                onlineClientToken = token.trim(),
                onlineConfigured = online.isConfigured,
                attemptOnline = false,
                onlineTestMessage = if (online.isConfigured) "Configuration saved. Test the connection before scanning." else "Enter a valid HTTPS backend URL and its demo access token.",
                isTestingOnlineConnection = false
            )
        }
    }

    fun testOnlineConnection() {
        val provider = online
        if (!provider.isConfigured) {
            _state.update { it.copy(onlineTestMessage = "Save a valid HTTPS backend URL and access token first.") }
            return
        }
        _state.update { it.copy(isTestingOnlineConnection = true, onlineTestMessage = "Checking backend and provider configuration…") }
        viewModelScope.launch {
            val message = withContext(Dispatchers.IO) {
                try {
                    provider.checkConnection()
                } catch (e: Exception) {
                    e.message ?: "Connection test failed. Check your endpoint and network."
                }
            }
            _state.update { it.copy(isTestingOnlineConnection = false, onlineTestMessage = message) }
        }
    }

    fun showCaptureError(message: String) {
        _state.update { it.copy(errorMessage = message.ifBlank { "Camera capture failed. Please try again or choose a photo." }) }
    }

    fun updateHomeSearch(query: String) {
        _state.update { it.copy(homeSearchQuery = query) }
    }

    override fun onCleared() {
        // Serialize close with any in-flight local inference so the native interpreter
        // is never closed while its classify() call is executing.
        synchronized(classifierLock) {
            runCatching { offline?.close() }
            offline = null
        }
        super.onCleared()
    }

    private fun userMessage(error: Throwable): String {
        return when (error) {
            is ClassifierException.OnlineNotConfigured ->
                "Online classification is not configured. No image was uploaded. Use on-device classification."
            is ClassifierException -> error.message ?: "Classification failed."
            else -> error.message ?: "Something went wrong while processing the image."
        }
    }
}
