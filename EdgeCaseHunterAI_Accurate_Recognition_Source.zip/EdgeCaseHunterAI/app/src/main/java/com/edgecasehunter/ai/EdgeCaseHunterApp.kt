package com.edgecasehunter.ai

import android.app.Application

class EdgeCaseHunterApp : Application()
