package com.edgecasehunter.ai.classification

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream

/** Produces a bounded JPEG payload for explicit online identification requests. */
object ImageUploadEncoder {
    private const val MAX_DIMENSION = 1280
    private const val JPEG_QUALITY = 84

    fun toJpegBytes(bitmap: Bitmap): ByteArray {
        if (bitmap.isRecycled || bitmap.width <= 0 || bitmap.height <= 0) {
            throw ClassifierException.UnsupportedImage("The selected image is no longer available. Please capture it again.")
        }

        var scaled: Bitmap? = null
        try {
            val longest = maxOf(bitmap.width, bitmap.height)
            val imageToEncode = if (longest > MAX_DIMENSION) {
                val ratio = MAX_DIMENSION.toFloat() / longest.toFloat()
                Bitmap.createScaledBitmap(
                    bitmap,
                    (bitmap.width * ratio).toInt().coerceAtLeast(1),
                    (bitmap.height * ratio).toInt().coerceAtLeast(1),
                    true
                ).also { if (it !== bitmap) scaled = it }
            } else bitmap

            return ByteArrayOutputStream().use { output ->
                val success = imageToEncode.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, output)
                if (!success) throw ClassifierException.UnsupportedImage("Unable to prepare the image for online identification.")
                output.toByteArray().also {
                    if (it.isEmpty()) throw ClassifierException.UnsupportedImage("The prepared image is empty.")
                }
            }
        } catch (e: OutOfMemoryError) {
            throw ClassifierException.UnsupportedImage("Not enough memory to prepare this image. Try a smaller photo.", e)
        } finally {
            scaled?.takeIf { !it.isRecycled }?.recycle()
        }
    }
}
