package com.edgecasehunter.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.edgecasehunter.ai.ui.camera.CameraView
import com.edgecasehunter.ai.ui.camera.ScanMode
import com.edgecasehunter.ai.ui.navigation.AppBottomNavigation
import com.edgecasehunter.ai.ui.navigation.AppDestination
import com.edgecasehunter.ai.ui.screens.ExploreScreen
import com.edgecasehunter.ai.ui.screens.HomeScreen
import com.edgecasehunter.ai.ui.screens.LibraryScreen
import com.edgecasehunter.ai.ui.screens.ResultScreen
import com.edgecasehunter.ai.ui.screens.ReviewScreen
import com.edgecasehunter.ai.ui.screens.SettingsDialog
import com.edgecasehunter.ai.ui.screens.ToolsScreen
import com.edgecasehunter.ai.ui.theme.AppColors

@Composable
fun ClassifierRoute(
    viewModel: ClassifierViewModel = viewModel()
) {
    val state by viewModel.state.collectAsState()

    ClassifierScreen(
        state = state,
        onDestinationSelected = viewModel::selectDestination,
        onModeChange = viewModel::setScanMode,
        onImageCaptured = viewModel::onImageCaptured,
        onCaptureError = viewModel::showCaptureError,
        onImagePicked = viewModel::onImagePicked,
        onIdentify = viewModel::identify,
        onToggleSave = viewModel::toggleSaveCurrentResult,
        onDeleteScan = viewModel::deleteSavedScan,
        onClearAllScans = viewModel::clearAllSavedScans,
        onOpenScanDetail = viewModel::openSavedScanDetail,
        onScanAgain = viewModel::scanAgain,
        onRetake = viewModel::retakeCapture,
        onToggleSettings = viewModel::toggleSettings,
        onToggleOnline = viewModel::setAttemptOnline,
        onSaveOnlineConfiguration = viewModel::saveOnlineConfiguration,
        onTestOnlineConnection = viewModel::testOnlineConnection,
        onHomeSearchChange = viewModel::updateHomeSearch
    )
}

/**
 * Root Composable Screen orchestrating 5 bottom destinations,
 * in-app CameraX capture, review sheet, detail results, and dialogs.
 */
@Composable
fun ClassifierScreen(
    state: ClassifierUiState,
    onDestinationSelected: (AppDestination) -> Unit,
    onModeChange: (ScanMode) -> Unit,
    onImageCaptured: (android.graphics.Bitmap) -> Unit,
    onCaptureError: (String) -> Unit,
    onImagePicked: (Uri) -> Unit,
    onIdentify: () -> Unit,
    onToggleSave: () -> Unit,
    onDeleteScan: (String) -> Unit,
    onClearAllScans: () -> Unit,
    onOpenScanDetail: (com.edgecasehunter.ai.data.SavedScan) -> Unit,
    onScanAgain: () -> Unit,
    onRetake: () -> Unit,
    onToggleSettings: (Boolean) -> Unit,
    onToggleOnline: (Boolean) -> Unit,
    onSaveOnlineConfiguration: (String, String) -> Unit,
    onTestOnlineConnection: () -> Unit,
    onHomeSearchChange: (String) -> Unit
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    // Check camera permission state
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onImagePicked(uri)
        }
    }

    // Handle Android Back button logically
    BackHandler(enabled = state.subState != AppSubState.DEFAULT) {
        when (state.subState) {
            AppSubState.REVIEW -> onRetake()
            AppSubState.RESULT -> onScanAgain()
            AppSubState.DEFAULT -> {}
        }
    }

    // Display error snackbar if error exists
    LaunchedEffect(state.errorMessage) {
        state.errorMessage?.let { error ->
            snackbarHostState.showSnackbar(error)
        }
    }

    Scaffold(
        bottomBar = {
            // Keep bottom nav accessible on main screens
            if (state.subState == AppSubState.DEFAULT) {
                AppBottomNavigation(
                    currentDestination = state.currentDestination,
                    onDestinationSelected = onDestinationSelected
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = AppColors.Background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Screen switching based on subState and destination
            when (state.subState) {
                AppSubState.REVIEW -> {
                    state.preview?.let { bmp ->
                        ReviewScreen(
                            bitmap = bmp,
                            scanMode = state.scanMode,
                            attemptOnline = state.attemptOnline,
                            onlineConfigured = state.onlineConfigured,
                            onToggleOnline = onToggleOnline,
                            onRetake = onRetake,
                            onIdentify = onIdentify
                        )
                    }
                }

                AppSubState.RESULT -> {
                    ResultScreen(
                        previewBitmap = state.preview,
                        result = state.result,
                        extractedText = state.extractedText,
                        barcodeValue = state.barcodeValue,
                        isSaved = state.isCurrentResultSaved,
                        onToggleSave = onToggleSave,
                        onBack = onScanAgain,
                        onScanAgain = onScanAgain
                    )
                }

                AppSubState.DEFAULT -> {
                    when (state.currentDestination) {
                        AppDestination.HOME -> {
                            HomeScreen(
                                savedScans = state.savedScans,
                                searchQuery = state.homeSearchQuery,
                                onSearchChange = onHomeSearchChange,
                                onOpenScan = { mode ->
                                    onModeChange(mode)
                                    onDestinationSelected(AppDestination.SCAN)
                                },
                                onOpenScanDetail = onOpenScanDetail,
                                onViewAllLibrary = { onDestinationSelected(AppDestination.LIBRARY) },
                                onOpenSettings = { onToggleSettings(true) }
                            )
                        }

                        AppDestination.EXPLORE -> {
                            ExploreScreen(
                                onCategoryClick = { category ->
                                    onModeChange(ScanMode.PHOTO)
                                    onDestinationSelected(AppDestination.SCAN)
                                },
                                onStartScanWithHint = { _ ->
                                    onModeChange(ScanMode.PHOTO)
                                    onDestinationSelected(AppDestination.SCAN)
                                }
                            )
                        }

                        AppDestination.SCAN -> {
                            if (hasCameraPermission) {
                                CameraView(
                                    currentMode = state.scanMode,
                                    onModeChange = onModeChange,
                                    onImageCaptured = onImageCaptured,
                                    onCaptureError = onCaptureError,
                                    onOpenGallery = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    }
                                )
                            } else {
                                // Camera Permission Needed State with Gallery Fallback
                                CameraPermissionFallbackView(
                                    onRequestPermission = {
                                        permissionLauncher.launch(Manifest.permission.CAMERA)
                                    },
                                    onOpenGallery = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    }
                                )
                            }
                        }

                        AppDestination.LIBRARY -> {
                            LibraryScreen(
                                savedScans = state.savedScans,
                                onOpenScanDetail = onOpenScanDetail,
                                onDeleteScan = onDeleteScan,
                                onClearAll = onClearAllScans,
                                onStartScan = { onDestinationSelected(AppDestination.SCAN) }
                            )
                        }

                        AppDestination.TOOLS -> {
                            ToolsScreen(
                                onLaunchScanMode = { mode ->
                                    onModeChange(mode)
                                    onDestinationSelected(AppDestination.SCAN)
                                }
                            )
                        }
                    }
                }
            }

            // Loading overlay
            if (state.isLoading) {
                Surface(
                    color = Color.Black.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = AppColors.Surface),
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .padding(24.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                CircularProgressIndicator(color = AppColors.Primary)
                                Text(
                                    text = state.loadingMessage.ifBlank { "Processing image on-device..." },
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = AppColors.TextPrimary,
                                    textAlign = TextAlign.Center
                                )
                                LinearProgressIndicator(
                                    modifier = Modifier.fillMaxWidth(),
                                    color = AppColors.Primary,
                                    trackColor = AppColors.SurfaceSubtle
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Settings & Diagnostics Dialog
    if (state.showSettings) {
        SettingsDialog(
            onlineConfigured = state.onlineConfigured,
            onlineEndpoint = state.onlineEndpoint,
            onlineClientToken = state.onlineClientToken,
            onlineTestMessage = state.onlineTestMessage,
            isTestingOnlineConnection = state.isTestingOnlineConnection,
            onSaveOnlineConfiguration = onSaveOnlineConfiguration,
            onTestOnlineConnection = onTestOnlineConnection,
            onDismiss = { onToggleSettings(false) },
            onClearLibrary = onClearAllScans
        )
    }
}

/**
 * Fallback view shown when Camera permission is not granted.
 * Clearly explains why permission is required and provides an immediate Gallery alternative.
 */
@Composable
private fun CameraPermissionFallbackView(
    onRequestPermission: () -> Unit,
    onOpenGallery: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AppColors.Background)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .background(AppColors.PrimarySubtle, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = null,
                tint = AppColors.Primary,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Camera Permission Required",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = AppColors.TextPrimary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "To identify objects and read barcodes, EdgeCase Hunter AI needs access to your device camera. Camera preview stays in the app. A photo is uploaded only if you explicitly enable online detailed identification before running it.",
            fontSize = 13.sp,
            color = AppColors.TextSecondary,
            textAlign = TextAlign.Center,
            lineHeight = 18.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onRequestPermission,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AppColors.Primary),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .semantics { contentDescription = "Grant camera permission" }
        ) {
            Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Grant Camera Permission", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = onOpenGallery,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .semantics { contentDescription = "Choose photo from gallery instead of camera" }
        ) {
            Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Choose from Gallery Instead", fontWeight = FontWeight.SemiBold)
        }
    }
}
