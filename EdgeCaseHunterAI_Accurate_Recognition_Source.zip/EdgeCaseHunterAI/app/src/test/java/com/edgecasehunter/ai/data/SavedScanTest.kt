package com.edgecasehunter.ai.data

import com.edgecasehunter.ai.classification.ScoredLabel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * Unit tests for SavedScan data model and JSON serialization.
 */
class SavedScanTest {

    @Test
    fun toJsonObject_and_fromJsonObject_preservesAllFields() {
        val predictions = listOf(
            ScoredLabel(rank = 1, index = 120, label = "Golden retriever", modelScore = 0.88f),
            ScoredLabel(rank = 2, index = 121, label = "Labrador retriever", modelScore = 0.08f)
        )

        val original = SavedScan(
            id = "test-uuid-1234",
            title = "Golden Retriever",
            category = "Animals",
            timestamp = 1700000000000L,
            source = "On-Device EfficientNet-Lite0",
            thumbnailPath = "/data/user/0/com.edgecasehunter.ai/files/thumbnails/thumb_test.jpg",
            inferenceTimeMs = 35L,
            confidence = 0.88f,
            extractedText = "Sample dog tag text",
            barcodeValue = "0123456789",
            alternativePredictions = predictions
        )

        val json = original.toJsonObject()
        val parsed = SavedScan.fromJsonObject(json)

        assertEquals("test-uuid-1234", parsed.id)
        assertEquals("Golden Retriever", parsed.title)
        assertEquals("Animals", parsed.category)
        assertEquals(1700000000000L, parsed.timestamp)
        assertEquals("On-Device EfficientNet-Lite0", parsed.source)
        assertEquals("/data/user/0/com.edgecasehunter.ai/files/thumbnails/thumb_test.jpg", parsed.thumbnailPath)
        assertEquals(35L, parsed.inferenceTimeMs)
        assertEquals(0.88f, parsed.confidence, 0.001f)
        assertEquals("Sample dog tag text", parsed.extractedText)
        assertEquals("0123456789", parsed.barcodeValue)

        assertEquals(2, parsed.alternativePredictions.size)
        assertEquals("Golden retriever", parsed.alternativePredictions[0].label)
        assertEquals(1, parsed.alternativePredictions[0].rank)
        assertEquals(0.88f, parsed.alternativePredictions[0].modelScore, 0.001f)
        assertEquals("Labrador retriever", parsed.alternativePredictions[1].label)
    }

    @Test
    fun fromJsonObject_handlesEmptyOptionalFields() {
        val scan = SavedScan(
            id = "scan-empty-fields",
            title = "Unknown Object",
            category = "General",
            source = "On-Device"
        )

        val json = scan.toJsonObject()
        val parsed = SavedScan.fromJsonObject(json)

        assertEquals("scan-empty-fields", parsed.id)
        assertNull(parsed.thumbnailPath)
        assertNull(parsed.extractedText)
        assertNull(parsed.barcodeValue)
        assertEquals(0, parsed.alternativePredictions.size)
    }
}
