package com.edgecasehunter.ai.ui

import com.edgecasehunter.ai.classification.ClassifierException
import com.edgecasehunter.ai.classification.UnconfiguredOnlineImageClassifier
import com.edgecasehunter.ai.ui.camera.ScanMode
import com.edgecasehunter.ai.ui.navigation.AppDestination
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for navigation destinations, scan mode contracts, and offline safety.
 */
class NavigationStateTest {

    @Test
    fun appDestinations_hasExactlyFiveMainItems() {
        val destinations = AppDestination.values()
        assertEquals(5, destinations.size)
        assertEquals("Home", destinations[0].title)
        assertEquals("Explore", destinations[1].title)
        assertEquals("Scan", destinations[2].title)
        assertEquals("Library", destinations[3].title)
        assertEquals("Tools", destinations[4].title)
    }

    @Test
    fun scanModes_coversRequiredModes() {
        val modes = ScanMode.values()
        assertEquals(4, modes.size)
        assertEquals("Photo", modes[0].label)
        assertEquals("Text", modes[1].label)
        assertEquals("Barcode", modes[2].label)
        assertEquals("Multi", modes[3].label)
    }

    @Test
    fun unconfiguredOnlineClassifier_rejectsImageUpload() {
        val onlineClassifier = UnconfiguredOnlineImageClassifier()
        assertFalse("Online classifier must report isConfigured=false", onlineClassifier.isConfigured)

        assertThrows(ClassifierException.OnlineNotConfigured::class.java) {
            runBlocking {
                onlineClassifier.classify(ByteArray(10))
            }
        }
    }
}
