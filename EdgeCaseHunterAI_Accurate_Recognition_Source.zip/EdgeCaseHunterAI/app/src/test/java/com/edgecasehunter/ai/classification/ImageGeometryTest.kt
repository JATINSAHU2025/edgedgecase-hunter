package com.edgecasehunter.ai.classification

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class ImageGeometryTest {
    @Test
    fun centerCrop_squareImage_usesFullFrame() {
        val crop = ImageGeometry.centerCrop(224, 224)
        assertEquals(0, crop.left)
        assertEquals(0, crop.top)
        assertEquals(224, crop.size)
    }

    @Test
    fun centerCrop_wideImage_cropsHorizontally() {
        val crop = ImageGeometry.centerCrop(400, 200)
        assertEquals(100, crop.left)
        assertEquals(0, crop.top)
        assertEquals(200, crop.size)
    }

    @Test
    fun centerCrop_tallImage_cropsVertically() {
        val crop = ImageGeometry.centerCrop(100, 300)
        assertEquals(0, crop.left)
        assertEquals(100, crop.top)
        assertEquals(100, crop.size)
    }

    @Test
    fun cropAndResize_preservesRgbCenterPixel() {
        val width = 4
        val height = 2
        val rgb = ByteArray(width * height * 3)
        fun setPixel(x: Int, y: Int, r: Int, g: Int, b: Int) {
            val i = (y * width + x) * 3
            rgb[i] = r.toByte()
            rgb[i + 1] = g.toByte()
            rgb[i + 2] = b.toByte()
        }
        setPixel(1, 0, 10, 20, 30)
        setPixel(2, 0, 40, 50, 60)
        val crop = ImageGeometry.centerCrop(width, height)
        val cropped = ImageGeometry.cropRgb(rgb, width, height, crop)
        assertEquals(2 * 2 * 3, cropped.size)
        val resized = ImageGeometry.resizeRgbNearest(cropped, crop.size, crop.size, 2)
        assertEquals(2 * 2 * 3, resized.size)
    }

    @Test
    fun centerCrop_rejectsInvalidSize() {
        assertThrows(IllegalArgumentException::class.java) {
            ImageGeometry.centerCrop(0, 10)
        }
    }
}
