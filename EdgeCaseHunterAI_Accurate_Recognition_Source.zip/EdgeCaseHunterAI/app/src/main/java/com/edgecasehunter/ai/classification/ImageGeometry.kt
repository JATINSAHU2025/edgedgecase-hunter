package com.edgecasehunter.ai.classification

/**
 * Geometry used by EfficientNet-Lite0: square center crop, then resize to 224x224.
 * TensorFlow Lite Task Vision applies the matching metadata ops at inference time;
 * this class is the documented, testable equivalent of those steps.
 */
object ImageGeometry {
    const val EFFICIENTNET_LITE0_INPUT_SIZE = 224

    fun centerCrop(width: Int, height: Int): CropRect {
        require(width > 0) { "Image width must be positive, was $width" }
        require(height > 0) { "Image height must be positive, was $height" }
        val size = minOf(width, height)
        val left = (width - size) / 2
        val top = (height - size) / 2
        return CropRect(left = left, top = top, size = size)
    }

    /**
     * Nearest-neighbor resize of an RGB buffer (3 bytes per pixel, row-major).
     * Used in unit tests; on-device inference uses TFLite metadata preprocessing.
     */
    fun resizeRgbNearest(
        source: ByteArray,
        sourceWidth: Int,
        sourceHeight: Int,
        targetSize: Int = EFFICIENTNET_LITE0_INPUT_SIZE
    ): ByteArray {
        require(source.size == sourceWidth * sourceHeight * 3) {
            "RGB buffer size ${source.size} does not match ${sourceWidth}x${sourceHeight}x3"
        }
        require(targetSize > 0)
        val dest = ByteArray(targetSize * targetSize * 3)
        for (y in 0 until targetSize) {
            val srcY = (y * sourceHeight) / targetSize
            for (x in 0 until targetSize) {
                val srcX = (x * sourceWidth) / targetSize
                val srcIndex = (srcY * sourceWidth + srcX) * 3
                val destIndex = (y * targetSize + x) * 3
                dest[destIndex] = source[srcIndex]
                dest[destIndex + 1] = source[srcIndex + 1]
                dest[destIndex + 2] = source[srcIndex + 2]
            }
        }
        return dest
    }

    fun cropRgb(
        source: ByteArray,
        sourceWidth: Int,
        sourceHeight: Int,
        crop: CropRect
    ): ByteArray {
        require(source.size == sourceWidth * sourceHeight * 3)
        require(crop.left >= 0 && crop.top >= 0)
        require(crop.left + crop.size <= sourceWidth)
        require(crop.top + crop.size <= sourceHeight)
        val dest = ByteArray(crop.size * crop.size * 3)
        for (y in 0 until crop.size) {
            val srcRow = ((crop.top + y) * sourceWidth + crop.left) * 3
            val destRow = y * crop.size * 3
            System.arraycopy(source, srcRow, dest, destRow, crop.size * 3)
        }
        return dest
    }
}
