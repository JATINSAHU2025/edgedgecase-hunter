package com.edgecasehunter.ai.data

import android.content.Context
import android.graphics.Bitmap
import com.edgecasehunter.ai.classification.ScoredLabel
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Data model for an item saved to the user's Library.
 * Stores minimal metadata and a thumbnail path per the design specification.
 */
data class SavedScan(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val category: String,
    val timestamp: Long = System.currentTimeMillis(),
    val source: String,
    val thumbnailPath: String? = null,
    val inferenceTimeMs: Long = 0L,
    val confidence: Float = 0f,
    val extractedText: String? = null,
    val barcodeValue: String? = null,
    val alternativePredictions: List<ScoredLabel> = emptyList()
) {
    fun toJsonObject(): JSONObject {
        val json = JSONObject()
        json.put("id", id)
        json.put("title", title)
        json.put("category", category)
        json.put("timestamp", timestamp)
        json.put("source", source)
        json.put("thumbnailPath", thumbnailPath ?: "")
        json.put("inferenceTimeMs", inferenceTimeMs)
        json.put("confidence", confidence.toDouble())
        json.put("extractedText", extractedText ?: "")
        json.put("barcodeValue", barcodeValue ?: "")

        val predictionsArray = JSONArray()
        for (pred in alternativePredictions) {
            val pObj = JSONObject()
            pObj.put("rank", pred.rank)
            pObj.put("index", pred.index)
            pObj.put("label", pred.label)
            pObj.put("modelScore", pred.modelScore.toDouble())
            predictionsArray.put(pObj)
        }
        json.put("alternativePredictions", predictionsArray)
        return json
    }

    companion object {
        fun fromJsonObject(json: JSONObject): SavedScan {
            val predictionsList = mutableListOf<ScoredLabel>()
            val preds = json.optJSONArray("alternativePredictions")
            if (preds != null) {
                for (i in 0 until preds.length()) {
                    val p = preds.getJSONObject(i)
                    predictionsList.add(
                        ScoredLabel(
                            rank = p.getInt("rank"),
                            index = p.getInt("index"),
                            label = p.getString("label"),
                            modelScore = p.getDouble("modelScore").toFloat()
                        )
                    )
                }
            }

            return SavedScan(
                id = json.getString("id"),
                title = json.getString("title"),
                category = json.optString("category", "General"),
                timestamp = json.optLong("timestamp", System.currentTimeMillis()),
                source = json.optString("source", "On-Device"),
                thumbnailPath = json.optString("thumbnailPath").ifEmpty { null },
                inferenceTimeMs = json.optLong("inferenceTimeMs", 0L),
                confidence = json.optDouble("confidence", 0.0).toFloat(),
                extractedText = json.optString("extractedText").ifEmpty { null },
                barcodeValue = json.optString("barcodeValue").ifEmpty { null },
                alternativePredictions = predictionsList
            )
        }
    }
}

/**
 * Repository for managing user-saved scans in local storage.
 * Strictly adheres to privacy policy:
 * - Records are only created when explicitly initiated by user.
 * - Thumbnails are stored in internal app files directory.
 * - Supports searching, category filtering, individual item deletion, and full clear.
 */
class LibraryRepository(private val context: Context) {

    private val storageFile: File
        get() = File(context.filesDir, "library_scans.json")

    private val thumbnailsDir: File
        get() = File(context.filesDir, "thumbnails").apply { mkdirs() }

    @Synchronized
    fun getAll(): List<SavedScan> {
        val file = storageFile
        if (!file.exists()) return emptyList()

        return try {
            val content = file.readText()
            val array = JSONArray(content)
            val list = mutableListOf<SavedScan>()
            for (i in 0 until array.length()) {
                list.add(SavedScan.fromJsonObject(array.getJSONObject(i)))
            }
            list.sortedByDescending { it.timestamp }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun getById(id: String): SavedScan? {
        return getAll().firstOrNull { it.id == id }
    }

    @Synchronized
    fun save(scan: SavedScan, thumbnailBitmap: Bitmap? = null): SavedScan {
        var finalScan = scan
        if (thumbnailBitmap != null) {
            try {
                val thumbFile = File(thumbnailsDir, "thumb_${scan.id}.jpg")
                FileOutputStream(thumbFile).use { out ->
                    thumbnailBitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
                }
                finalScan = scan.copy(thumbnailPath = thumbFile.absolutePath)
            } catch (e: Exception) {
                // If thumbnail save fails, keep original metadata
            }
        }

        val current = getAll().toMutableList()
        // If an item with same ID or same title from recent scan exists, update or insert
        val existingIndex = current.indexOfFirst { it.id == finalScan.id }
        if (existingIndex >= 0) {
            current[existingIndex] = finalScan
        } else {
            current.add(0, finalScan)
        }

        persist(current)
        return finalScan
    }

    @Synchronized
    fun delete(id: String): Boolean {
        val current = getAll().toMutableList()
        val item = current.firstOrNull { it.id == id } ?: return false
        item.thumbnailPath?.let { path ->
            val f = File(path)
            if (f.exists()) f.delete()
        }
        current.removeAll { it.id == id }
        persist(current)
        return true
    }

    @Synchronized
    fun clearAll() {
        getAll().forEach { item ->
            item.thumbnailPath?.let { path ->
                val f = File(path)
                if (f.exists()) f.delete()
            }
        }
        val file = storageFile
        if (file.exists()) {
            file.delete()
        }
    }

    private fun persist(items: List<SavedScan>) {
        val array = JSONArray()
        for (item in items) {
            array.put(item.toJsonObject())
        }
        val file = storageFile
        file.writeText(array.toString())
    }
}
