package com.edgecasehunter.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.edgecasehunter.ai.BuildConfig
import com.edgecasehunter.ai.ui.components.StatusBadge
import com.edgecasehunter.ai.ui.theme.AppColors

/**
 * Settings & Technical Diagnostics Dialog.
 * Transparently reports on-device model metadata, offline guarantees,
 * and security disclosures.
 */
@Composable
fun SettingsDialog(
    onlineConfigured: Boolean,
    onlineEndpoint: String,
    onlineClientToken: String,
    onlineTestMessage: String?,
    isTestingOnlineConnection: Boolean,
    onSaveOnlineConfiguration: (String, String) -> Unit,
    onTestOnlineConnection: () -> Unit,
    onDismiss: () -> Unit,
    onClearLibrary: () -> Unit
) {
    var endpointInput by remember(onlineEndpoint) {
        mutableStateOf(onlineEndpoint.removeSuffix("/classify"))
    }
    var tokenInput by remember(onlineClientToken) { mutableStateOf(onlineClientToken) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", fontWeight = FontWeight.Bold)
            }
        },
        title = {
            Text(
                text = "Settings & Diagnostics",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Section 1: Appearance & Privacy
                Text("Privacy & Storage Policy", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AppColors.TextPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = AppColors.SurfaceSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Default Theme", fontSize = 12.sp, color = AppColors.TextSecondary)
                            Text("Light Mode", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AppColors.TextPrimary)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Data Retention", fontSize = 12.sp, color = AppColors.TextSecondary)
                            Text("User Choice (Opt-In)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AppColors.Success)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Network Access", fontSize = 12.sp, color = AppColors.TextSecondary)
                            StatusBadge(
                                if (onlineConfigured) "ONLINE AVAILABLE (OPT-IN)" else "OFFLINE ONLY",
                                if (onlineConfigured) AppColors.Primary else AppColors.Success,
                                if (onlineConfigured) AppColors.PrimarySubtle else AppColors.SuccessSubtle
                            )
                        }
                    }
                }

                HorizontalDivider(color = AppColors.Border)

                // Section 2: Model Attribution
                Text("Model Attribution", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AppColors.TextPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = AppColors.SurfaceSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Model Name: ${BuildConfig.MODEL_DISPLAY_NAME}", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        Text("Artifact: ${BuildConfig.MODEL_REVISION}.tflite", fontSize = 11.sp, color = AppColors.TextSecondary)
                        Text("SHA-256: ${BuildConfig.MODEL_SHA256}", fontSize = 10.sp, color = AppColors.TextMuted, lineHeight = 13.sp)
                        Text("Input Dimensions: ${BuildConfig.MODEL_INPUT_SIZE}x${BuildConfig.MODEL_INPUT_SIZE} INT8", fontSize = 11.sp, color = AppColors.TextSecondary)
                        Text("License: Apache License 2.0 (TensorFlow Lite Task Vision)", fontSize = 11.sp, color = AppColors.TextSecondary)
                    }
                }

                HorizontalDivider(color = AppColors.Border)

                // Section 3: Online Endpoint Status and runtime configuration
                Text("Online Vision Provider", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AppColors.TextPrimary)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = AppColors.SurfaceSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = if (onlineConfigured) "Status: HTTPS endpoint and access token configured" else "Status: Offline-only until configured",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (onlineConfigured) AppColors.Success else AppColors.TextSecondary
                        )
                        Text(
                            text = "Deploy the included backend first. Enter its public HTTPS base URL below; the app adds /classify automatically. Your Gemini API key belongs on the backend, never here.",
                            fontSize = 10.sp,
                            color = AppColors.TextMuted,
                            lineHeight = 14.sp
                        )
                        OutlinedTextField(
                            value = endpointInput,
                            onValueChange = { endpointInput = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Backend HTTPS base URL") },
                            placeholder = { Text("https://your-service.example") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                        )
                        OutlinedTextField(
                            value = tokenInput,
                            onValueChange = { tokenInput = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Demo backend access token") },
                            placeholder = { Text("Token set in backend environment") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                        )
                        Text(
                            "This is only the demo backend token, not the Gemini API key. A token entered in an APK is extractable; use this only for a private demo, not as production authentication.",
                            fontSize = 10.sp,
                            color = AppColors.TextMuted,
                            lineHeight = 14.sp
                        )
                        Button(
                            onClick = { onSaveOnlineConfiguration(endpointInput, tokenInput) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Save online configuration")
                        }
                        Button(
                            onClick = onTestOnlineConnection,
                            modifier = Modifier.fillMaxWidth(),
                            enabled = onlineConfigured && !isTestingOnlineConnection
                        ) {
                            if (isTestingOnlineConnection) {
                                CircularProgressIndicator(modifier = Modifier.padding(end = 8.dp), strokeWidth = 2.dp)
                            }
                            Text(if (isTestingOnlineConnection) "Testing connection…" else "Test backend connection")
                        }
                        onlineTestMessage?.let { message ->
                            Text(
                                text = message,
                                fontSize = 11.sp,
                                color = if (message.startsWith("Connection successful")) AppColors.Success else AppColors.TextSecondary,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }
    )
}
