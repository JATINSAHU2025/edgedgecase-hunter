package com.edgecasehunter.ai.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.edgecasehunter.ai.BuildConfig
import com.edgecasehunter.ai.classification.CatalogMatch
import com.edgecasehunter.ai.classification.ClassificationResult
import com.edgecasehunter.ai.classification.ResultSource
import com.edgecasehunter.ai.classification.ScoredLabel
import com.edgecasehunter.ai.data.SavedScan
import com.edgecasehunter.ai.ui.components.StatusBadge
import com.edgecasehunter.ai.ui.theme.AppColors

/**
 * 04 — Identification Result Screen
 * Rich inspector with detail tabs: About, Visual Clues, Similar, and Text/Barcode.
 */
@Composable
fun ResultScreen(
    previewBitmap: Bitmap?,
    result: ClassificationResult?,
    extractedText: String?,
    barcodeValue: String?,
    isSaved: Boolean,
    onToggleSave: () -> Unit,
    onBack: () -> Unit,
    onScanAgain: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var showAskDialog by remember { mutableStateOf(false) }

    val tabs = listOf("About", "Visual Clues", "Similar", "Text & Code")

    val topLabel = result?.topPredictions?.firstOrNull()
    val primaryTitle = when {
        barcodeValue != null -> "Barcode / QR Payload"
        extractedText?.isNotBlank() == true && result == null -> "Extracted Text"
        topLabel != null -> topLabel.label.replaceFirstChar { it.uppercase() }
        else -> "Visual Analysis Result"
    }

    val sourceBadgeText = when {
        barcodeValue != null -> "ML KIT BARCODE"
        extractedText?.isNotBlank() == true && result == null -> "ML KIT OCR"
        result?.source == ResultSource.ONLINE -> "ONLINE VISUAL MODEL"
        result?.source == ResultSource.ON_DEVICE -> "ON-DEVICE TFLITE"
        else -> "LOCAL INFERENCE"
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AppColors.Background)
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.semantics { contentDescription = "Return to camera" }
            ) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = AppColors.TextPrimary)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                // Share button
                IconButton(
                    onClick = {
                        val sendIntent: Intent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(
                                Intent.EXTRA_TEXT,
                                "EdgeCase Hunter AI Identification:\n$primaryTitle\nSource: $sourceBadgeText"
                            )
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Share result"))
                    },
                    modifier = Modifier.semantics { contentDescription = "Share identification summary" }
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = AppColors.TextSecondary)
                }

                // Bookmark / Save toggle
                IconButton(
                    onClick = onToggleSave,
                    modifier = Modifier.semantics { contentDescription = if (isSaved) "Remove from saved library" else "Save to library" }
                ) {
                    Icon(
                        imageVector = if (isSaved) Icons.Filled.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = null,
                        tint = if (isSaved) AppColors.Primary else AppColors.TextSecondary
                    )
                }
            }
        }

        // Scrollable content area
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Main captured image preview
            if (previewBitmap != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.Black)
                ) {
                    Image(
                        bitmap = previewBitmap.asImageBitmap(),
                        contentDescription = "Analyzed image preview",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
            }

            // Primary Identity Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = AppColors.Surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, AppColors.Border),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusBadge(
                            text = sourceBadgeText,
                            textColor = AppColors.Success,
                            backgroundColor = AppColors.SuccessSubtle,
                            dotColor = AppColors.Success
                        )

                        if (result != null) {
                            Text(
                                text = "${result.inferenceTimeMs}ms",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppColors.TextSecondary
                            )
                        }
                    }

                    Text(
                        text = primaryTitle,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = AppColors.TextPrimary
                    )

                    if (topLabel != null && result?.source == ResultSource.ON_DEVICE) {
                        Text(
                            text = "Model score: ${"%.1f".format(topLabel.modelScore * 100)}% · not a guarantee of correctness",
                            fontSize = 12.sp,
                            color = AppColors.TextSecondary
                        )
                    } else if (result?.source == ResultSource.ONLINE && !result.uncertainty.isNullOrBlank()) {
                        Text(
                            text = "Visual identification uncertainty: ${result.uncertainty}",
                            fontSize = 12.sp,
                            color = AppColors.TextSecondary
                        )
                    }

                    Text(
                        text = when {
                            result?.source == ResultSource.ONLINE -> "Identified using ${result.modelName}. Online mode sends this image to your configured vision service; visual identifications may still be wrong."
                            result?.source == ResultSource.ON_DEVICE -> "Identified with a local ImageNet classifier. It is limited to its 1,000-class vocabulary and may not know the exact product or object type."
                            barcodeValue != null -> "Barcode data was decoded on this device."
                            else -> "Text was extracted on this device."
                        },
                        fontSize = 11.sp,
                        color = AppColors.TextMuted,
                        lineHeight = 15.sp
                    )
                }
            }

            // Detail Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.Transparent,
                contentColor = AppColors.Primary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = AppColors.Primary
                    )
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    )
                }
            }

            // Tab Content
            when (selectedTab) {
                0 -> AboutTab(result, primaryTitle)
                1 -> VisualCluesTab(result)
                2 -> SimilarTab(result)
                3 -> TextAndCodeTab(extractedText, barcodeValue)
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Bottom Fixed Actions Bar
        Surface(
            color = AppColors.Surface,
            shadowElevation = 8.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, AppColors.Border),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onScanAgain,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Scan again")
                }

                Button(
                    onClick = { showAskDialog = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AppColors.Primary),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Ask about it")
                }
            }
        }
    }

    if (showAskDialog) {
        AlertDialog(
            onDismissRequest = { showAskDialog = false },
            title = { Text("Ask About Object") },
            text = {
                Text(
                    if (result?.source == ResultSource.ONLINE) {
                        "Follow-up questions are not yet implemented by this provider integration. The current online result contains the identification and visible clues returned for this photo."
                    } else {
                        "For a more detailed identification, return to the photo review screen and enable Online detailed identification when a secure backend is configured. The image is uploaded only after you explicitly enable that mode."
                    }
                )
            },
            confirmButton = {
                TextButton(onClick = { showAskDialog = false }) {
                    Text("Understood", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
private fun AboutTab(result: ClassificationResult?, primaryTitle: String) {
    if (result?.source == ResultSource.ONLINE) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = AppColors.Surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, AppColors.Border),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("What it appears to be", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = AppColors.TextPrimary)
                Text(
                    result.description ?: "The online model identified this as $primaryTitle, but did not provide a detailed description.",
                    color = AppColors.TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Text("Provider", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AppColors.TextPrimary)
                Text(result.modelName, color = AppColors.TextSecondary, fontSize = 12.sp)
                if (!result.uncertainty.isNullOrBlank()) {
                    Text("Uncertainty: ${result.uncertainty}", color = AppColors.TextSecondary, fontSize = 12.sp)
                }
                Text(
                    "A photograph may support the general object type without proving exact size, make, model or material.",
                    color = AppColors.TextMuted,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }
        return
    }
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AppColors.Surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, AppColors.Border),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Model Specifications", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = AppColors.TextPrimary)

            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Classifier Architecture", color = AppColors.TextSecondary, fontSize = 12.sp)
                Text(BuildConfig.MODEL_DISPLAY_NAME, color = AppColors.TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("TFLite Model Revision", color = AppColors.TextSecondary, fontSize = 12.sp)
                Text(BuildConfig.MODEL_REVISION, color = AppColors.TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Input Resolution", color = AppColors.TextSecondary, fontSize = 12.sp)
                Text("${BuildConfig.MODEL_INPUT_SIZE} × ${BuildConfig.MODEL_INPUT_SIZE} RGB", color = AppColors.TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Label Vocabulary", color = AppColors.TextSecondary, fontSize = 12.sp)
                Text("1,000 ImageNet-1K Classes", color = AppColors.TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Inference Dispatch", color = AppColors.TextSecondary, fontSize = 12.sp)
                Text("4-Thread CPU (Off UI Thread)", color = AppColors.TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun VisualCluesTab(result: ClassificationResult?) {
    if (result?.source == ResultSource.ONLINE && (result.visibleFeatures.isNotEmpty() || !result.description.isNullOrBlank())) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = AppColors.Surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, AppColors.Border),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Visible clues", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = AppColors.TextPrimary)
                if (result.description?.isNotBlank() == true) {
                    Text(result.description, fontSize = 13.sp, color = AppColors.TextSecondary, lineHeight = 18.sp)
                }
                result.visibleFeatures.forEach { feature ->
                    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("•", color = AppColors.Primary, fontWeight = FontWeight.Bold)
                        Text(feature, fontSize = 13.sp, color = AppColors.TextPrimary, lineHeight = 18.sp)
                    }
                }
                if (result.visibleFeatures.isEmpty()) {
                    Text("No separate visual-feature list was returned by the online model.", color = AppColors.TextSecondary, fontSize = 12.sp)
                }
            }
        }
        return
    }
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AppColors.Surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, AppColors.Border),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Observable Evidence vs Inferred Labels", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = AppColors.TextPrimary)

            if (result?.source == ResultSource.ONLINE) {
                Text(
                    "Online identification does not expose a calibrated numeric confidence score.",
                    fontSize = 12.sp,
                    color = AppColors.TextMuted
                )
            } else if (result?.topPredictions?.isNotEmpty() == true) {
                result.topPredictions.forEach { prediction ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${prediction.rank}. ${prediction.label}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = AppColors.TextPrimary
                            )
                            Text(
                                text = "${"%.1f".format(prediction.modelScore * 100)}%",
                                fontSize = 12.sp,
                                color = AppColors.TextSecondary,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        LinearProgressIndicator(
                            progress = { prediction.modelScore.coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(999.dp)),
                            color = AppColors.Primary,
                            trackColor = AppColors.SurfaceSubtle
                        )
                    }
                }
            } else {
                Text(
                    text = "No neural classification predictions available for this capture.",
                    color = AppColors.TextSecondary,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun SimilarTab(result: ClassificationResult?) {
    val predictions = result?.topPredictions.orEmpty()
    val isOnline = result?.source == ResultSource.ONLINE
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (result?.catalogMatches?.isNotEmpty() == true) {
            Text(
                text = "Closest Catalog Products",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = AppColors.TextPrimary
            )
            result.catalogMatches.forEach { match -> CatalogMatchCard(match) }
        }

        Text(
            text = if (isOnline) "Alternative Possible Identifications" else "Alternative Classifier Candidates",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = AppColors.TextPrimary
        )

        val alternatives = predictions.drop(1)
        if (alternatives.isEmpty()) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AppColors.Surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "No secondary candidates identified.",
                    modifier = Modifier.padding(16.dp),
                    color = AppColors.TextSecondary,
                    fontSize = 13.sp
                )
            }
        } else {
            alternatives.forEach { alt ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = AppColors.Surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AppColors.Border),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = alt.label,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = AppColors.TextPrimary
                            )
                            if (!isOnline) {
                                Text(
                                    text = "ImageNet class index #${alt.index}",
                                    fontSize = 11.sp,
                                    color = AppColors.TextMuted
                                )
                            }
                        }

                        if (!isOnline) {
                            Text(
                                text = "${"%.1f".format(alt.modelScore * 100)}%",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppColors.Primary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CatalogMatchCard(match: CatalogMatch) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AppColors.Surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, AppColors.Border),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(match.name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = AppColors.TextPrimary)
            val details = listOf(
                match.sku.takeIf { it.isNotBlank() }?.let { "SKU: $it" },
                match.brand.takeIf { it.isNotBlank() }?.let { "Brand: $it" },
                match.dimensions.takeIf { it.isNotBlank() }?.let { "Size: $it" },
                match.category.takeIf { it.isNotBlank() }
            ).filterNotNull()
            if (details.isNotEmpty()) {
                Text(details.joinToString(" · "), fontSize = 11.sp, color = AppColors.TextSecondary)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = match.price.takeIf { it.isNotBlank() }?.let { "Price: $it" } ?: "Price unavailable",
                    fontSize = 12.sp, color = AppColors.TextSecondary
                )
                Text(
                    text = "Visual similarity ${(match.similarity * 100).coerceIn(0f, 100f).toInt()}%",
                    fontSize = 11.sp, fontWeight = FontWeight.Medium, color = AppColors.Primary
                )
            }
        }
    }
}

@Composable
private fun TextAndCodeTab(extractedText: String?, barcodeValue: String?) {
    val context = LocalContext.current

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AppColors.Surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, AppColors.Border),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (barcodeValue != null) {
                Text("Decoded Barcode / QR", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = AppColors.TextPrimary)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AppColors.SurfaceSubtle, RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(barcodeValue, fontSize = 13.sp, color = AppColors.TextPrimary, modifier = Modifier.weight(1f))
                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Barcode", barcodeValue))
                            Toast.makeText(context, "Copied barcode value", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy code", tint = AppColors.Primary)
                    }
                }
            }

            if (!extractedText.isNullOrBlank()) {
                Text("Extracted OCR Text", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = AppColors.TextPrimary)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AppColors.SurfaceSubtle, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(extractedText, fontSize = 13.sp, color = AppColors.TextPrimary, lineHeight = 18.sp)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Extracted Text", extractedText))
                                    Toast.makeText(context, "Copied text to clipboard", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Copy Text", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            if (barcodeValue == null && extractedText.isNullOrBlank()) {
                Text("No text or barcode symbols were detected in this image region.", color = AppColors.TextSecondary, fontSize = 12.sp)
            }
        }
    }
}
