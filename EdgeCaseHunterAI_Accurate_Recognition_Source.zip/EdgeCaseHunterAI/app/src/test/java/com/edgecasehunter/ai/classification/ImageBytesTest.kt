package com.edgecasehunter.ai.classification

import org.junit.Assert.assertThrows
import org.junit.Test

class ImageBytesTest {
    @Test
    fun jpegHeader_isAccepted() {
        val jpeg = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte(), 0x00, 0x10)
        ImageBytes.validateHeader(jpeg)
    }

    @Test
    fun pngHeader_isAccepted() {
        val png = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00)
        ImageBytes.validateHeader(png)
    }

    @Test
    fun emptyBytes_areRejected() {
        assertThrows(ClassifierException.UnsupportedImage::class.java) {
            ImageBytes.validateHeader(ByteArray(0))
        }
    }

    @Test
    fun randomBytes_areRejected() {
        assertThrows(ClassifierException.UnsupportedImage::class.java) {
            ImageBytes.validateHeader(byteArrayOf(0x00, 0x01, 0x02, 0x03, 0x04))
        }
    }

    @Test
    fun textFile_isRejected() {
        assertThrows(ClassifierException.UnsupportedImage::class.java) {
            ImageBytes.validateHeader("not an image".toByteArray())
        }
    }
}
