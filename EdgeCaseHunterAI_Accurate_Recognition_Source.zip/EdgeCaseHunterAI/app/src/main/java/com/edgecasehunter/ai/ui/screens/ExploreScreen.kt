package com.edgecasehunter.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalFlorist
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.edgecasehunter.ai.ui.camera.ScanMode
import com.edgecasehunter.ai.ui.components.AppSearchField
import com.edgecasehunter.ai.ui.components.EmptyStateView
import com.edgecasehunter.ai.ui.components.FilterChipItem
import com.edgecasehunter.ai.ui.theme.AppColors

data class CategoryItem(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val icon: ImageVector,
    val examples: List<String>
)

val EXPLORE_CATEGORIES = listOf(
    CategoryItem(
        id = "animals",
        title = "Animals & Wildlife",
        description = "Domestic pets, wild fauna, birds, marine species",
        category = "Animals",
        icon = Icons.Default.Pets,
        examples = listOf("Golden retriever", "Tabby cat", "Bald eagle", "Chameleon")
    ),
    CategoryItem(
        id = "plants",
        title = "Plants & Botany",
        description = "Flowering plants, foliage, trees, common houseplants",
        category = "Plants",
        icon = Icons.Default.LocalFlorist,
        examples = listOf("Monstera", "Daisy", "Sunflower", "Fiddle-leaf fig")
    ),
    CategoryItem(
        id = "electronics",
        title = "Consumer Electronics",
        description = "Hardware devices, computers, peripherals, gadgets",
        category = "Electronics",
        icon = Icons.Default.Computer,
        examples = listOf("Laptop", "Keyboard", "Digital SLR", "Microphone")
    ),
    CategoryItem(
        id = "home",
        title = "Home & Interior",
        description = "Furniture, kitchenware, appliances, indoor fixtures",
        category = "Home",
        icon = Icons.Default.Home,
        examples = listOf("Coffee mug", "Desk lamp", "Dining chair", "Electric kettle")
    ),
    CategoryItem(
        id = "tools",
        title = "Tools & Industrial",
        description = "Hand tools, mechanical valves, hardware components",
        category = "Objects",
        icon = Icons.Default.Category,
        examples = listOf("Industrial valve", "Adjustable wrench", "Screwdriver", "Measuring tape")
    ),
    CategoryItem(
        id = "text",
        title = "Printed Text & Documents",
        description = "Books, receipts, signs, serial labels with on-device OCR",
        category = "Objects",
        icon = Icons.Default.Search,
        examples = listOf("Product label", "Book page", "Ingredient list", "Invoice text")
    )
)

/**
 * 02 — Explore Categories Screen
 * Visual catalog of object categories supported on-device.
 */
@Composable
fun ExploreScreen(
    onCategoryClick: (CategoryItem) -> Unit,
    onStartScanWithHint: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") }

    val filterChips = listOf("All", "Animals", "Plants", "Objects", "Electronics", "Home")

    val filteredList = EXPLORE_CATEGORIES.filter { item ->
        val matchesCategory = selectedFilter == "All" || item.category.equals(selectedFilter, ignoreCase = true)
        val matchesQuery = searchQuery.isBlank() ||
                item.title.contains(searchQuery, ignoreCase = true) ||
                item.description.contains(searchQuery, ignoreCase = true) ||
                item.examples.any { it.contains(searchQuery, ignoreCase = true) }
        matchesCategory && matchesQuery
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AppColors.Background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Title & Description
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = "Explore Categories",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = AppColors.TextPrimary
            )
            Text(
                text = "Discover visual classes recognized reliably by the on-device model",
                fontSize = 13.sp,
                color = AppColors.TextSecondary
            )
        }

        // Search Field
        AppSearchField(
            query = searchQuery,
            onQueryChange = { searchQuery = it },
            placeholder = "Filter categories or example objects..."
        )

        // Filter Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            filterChips.forEach { chip ->
                FilterChipItem(
                    label = chip,
                    isSelected = selectedFilter == chip,
                    onClick = { selectedFilter = chip }
                )
            }
        }

        // Category Cards Grid / List
        if (filteredList.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.SearchOff,
                title = "No matching categories",
                message = "Try searching for a different term or reset your category filter.",
                actionText = "Reset Filters",
                onActionClick = {
                    searchQuery = ""
                    selectedFilter = "All"
                }
            )
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                filteredList.forEach { category ->
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = AppColors.Surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AppColors.Border),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .clickable { onCategoryClick(category) }
                            .semantics { contentDescription = "${category.title} category card" }
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(AppColors.PrimarySubtle, RoundedCornerShape(12.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = category.icon,
                                            contentDescription = null,
                                            tint = AppColors.Primary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }

                                    Column {
                                        Text(
                                            text = category.title,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = AppColors.TextPrimary
                                        )
                                        Text(
                                            text = category.category,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = AppColors.Primary
                                        )
                                    }
                                }

                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "Scan in this category",
                                    tint = AppColors.TextSecondary,
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clickable { onStartScanWithHint(category.title) }
                                )
                            }

                            Text(
                                text = category.description,
                                fontSize = 12.sp,
                                color = AppColors.TextSecondary,
                                lineHeight = 16.sp
                            )

                            // Examples row
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                category.examples.forEach { example ->
                                    Box(
                                        modifier = Modifier
                                            .background(AppColors.SurfaceSubtle, RoundedCornerShape(8.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = example,
                                            fontSize = 11.sp,
                                            color = AppColors.TextSecondary,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(60.dp))
    }
}
