package com.edgecasehunter.ai.classification

object LabelMapper {
    fun loadLabels(text: String): List<String> {
        val labels = text
            .split('\n', '\r')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
        require(labels.isNotEmpty()) { "Label file is empty" }
        return labels
    }

    fun topK(
        scores: FloatArray,
        labels: List<String>,
        k: Int = 5
    ): List<ScoredLabel> {
        require(k > 0) { "k must be positive" }
        require(scores.isNotEmpty()) { "Model produced an empty output tensor" }
        require(scores.size == labels.size) {
            "Output length ${scores.size} does not match label count ${labels.size}"
        }
        for (score in scores) {
            require(!score.isNaN()) { "Model produced NaN scores" }
            require(score.isFinite()) { "Model produced non-finite scores" }
        }
        val count = minOf(k, scores.size)
        return scores
            .mapIndexed { index, score -> index to score }
            .sortedByDescending { it.second }
            .take(count)
            .mapIndexed { rank, (index, score) ->
                ScoredLabel(
                    rank = rank + 1,
                    index = index,
                    label = labels[index],
                    modelScore = score
                )
            }
    }
}
