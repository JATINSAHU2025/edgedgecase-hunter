package com.edgecasehunter.ai.ui.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.ImageFormat
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.edgecasehunter.ai.ui.theme.AppColors
import java.nio.ByteBuffer
import java.util.concurrent.Executors

enum class ScanMode(val label: String, val hint: String) {
    PHOTO("Photo", "Point at an object to identify"),
    TEXT("Text", "Frame the text you want to read"),
    BARCODE("Barcode", "Align the barcode or QR code"),
    MULTI("Multi", "Frame all objects, then tap shutter")
}

/**
 * In-app CameraX live viewfinder.
 * Captures still images directly in-process without switching to an external camera app.
 */
@Composable
fun CameraView(
    currentMode: ScanMode,
    onModeChange: (ScanMode) -> Unit,
    onImageCaptured: (Bitmap) -> Unit,
    onCaptureError: (String) -> Unit,
    onOpenGallery: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var lensFacing by remember { mutableStateOf(CameraSelector.LENS_FACING_BACK) }
    var flashMode by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_OFF) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var cameraProvider by remember { mutableStateOf<ProcessCameraProvider?>(null) }
    var previewViewRef by remember { mutableStateOf<PreviewView?>(null) }
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { cameraProvider?.unbindAll() }
            cameraExecutor.shutdown()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // CameraX Live Preview Surface
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply {
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }
                previewViewRef = previewView

                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    val provider = cameraProviderFuture.get()
                    cameraProvider = provider

                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }

                    val capture = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .setFlashMode(flashMode)
                        .build()

                    imageCapture = capture

                    val selector = CameraSelector.Builder()
                        .requireLensFacing(lensFacing)
                        .build()

                    try {
                        provider.unbindAll()
                        provider.bindToLifecycle(lifecycleOwner, selector, preview, capture)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, ContextCompat.getMainExecutor(ctx))

                previewView
            },
            update = {
                // Handle dynamic updates if needed
            }
        )

        // Viewfinder Framing Guides (Corner Brackets)
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .size(270.dp)
                .border(2.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
        )

        // Top Controls Bar (Flash, Camera Switch, Offline Badge)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 24.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = AppColors.CameraOverlay,
                shape = RoundedCornerShape(999.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(AppColors.Success, CircleShape)
                    )
                    Text(
                        text = "CAMERA STAYS ON DEVICE",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Flash Toggle
                IconButton(
                    onClick = {
                        val newFlash = if (flashMode == ImageCapture.FLASH_MODE_OFF) {
                            ImageCapture.FLASH_MODE_ON
                        } else {
                            ImageCapture.FLASH_MODE_OFF
                        }
                        flashMode = newFlash
                        imageCapture?.flashMode = newFlash
                    },
                    modifier = Modifier
                        .size(42.dp)
                        .background(AppColors.CameraOverlay, CircleShape)
                        .semantics { contentDescription = "Toggle camera flash" }
                ) {
                    Icon(
                        imageVector = if (flashMode == ImageCapture.FLASH_MODE_ON) Icons.Default.FlashOn else Icons.Default.FlashOff,
                        contentDescription = null,
                        tint = if (flashMode == ImageCapture.FLASH_MODE_ON) Color(0xFFFFD54F) else Color.White
                    )
                }

                // Lens Switch (Back / Front)
                IconButton(
                    onClick = {
                        val newFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                            CameraSelector.LENS_FACING_FRONT
                        } else {
                            CameraSelector.LENS_FACING_BACK
                        }
                        lensFacing = newFacing

                        cameraProvider?.let { provider ->
                            val preview = Preview.Builder().build().also { useCase ->
                                previewViewRef?.surfaceProvider?.let(useCase::setSurfaceProvider)
                            }
                            val capture = ImageCapture.Builder()
                                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                                .setFlashMode(flashMode)
                                .build()
                            imageCapture = capture

                            val selector = CameraSelector.Builder()
                                .requireLensFacing(newFacing)
                                .build()

                            try {
                                provider.unbindAll()
                                provider.bindToLifecycle(lifecycleOwner, selector, preview, capture)
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    },
                    modifier = Modifier
                        .size(42.dp)
                        .background(AppColors.CameraOverlay, CircleShape)
                        .semantics { contentDescription = "Switch front and rear camera" }
                ) {
                    Icon(
                        imageVector = Icons.Default.Cameraswitch,
                        contentDescription = null,
                        tint = Color.White
                    )
                }
            }
        }

        // Bottom Controls Container
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = 0.45f))
                .padding(bottom = 16.dp, top = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Mode Contextual Hint
            Text(
                text = currentMode.hint,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Mode Selector Strip (Photo, Text, Barcode, Multi)
            Row(
                modifier = Modifier
                    .background(AppColors.CameraOverlay, RoundedCornerShape(999.dp))
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ScanMode.values().forEach { mode ->
                    val isSelected = mode == currentMode
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(if (isSelected) AppColors.Primary else Color.Transparent)
                            .clickable { onModeChange(mode) }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                            .semantics { contentDescription = "${mode.label} capture mode" }
                    ) {
                        Text(
                            text = mode.label,
                            color = if (isSelected) Color.White else Color.White.copy(alpha = 0.7f),
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Shutter & Side Actions Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Photo Picker (Left side)
                IconButton(
                    onClick = onOpenGallery,
                    modifier = Modifier
                        .size(48.dp)
                        .background(AppColors.CameraOverlay, CircleShape)
                        .semantics { contentDescription = "Choose image from photo library" }
                ) {
                    Icon(
                        imageVector = Icons.Default.PhotoLibrary,
                        contentDescription = null,
                        tint = Color.White
                    )
                }

                // Tactile Shutter Button (Center, 72dp per component tokens)
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .border(4.dp, Color.White, CircleShape)
                        .padding(5.dp)
                        .background(Color.White, CircleShape)
                        .clickable {
                            val capture = imageCapture ?: return@clickable
                            capture.takePicture(
                                cameraExecutor,
                                object : ImageCapture.OnImageCapturedCallback() {
                                    override fun onCaptureSuccess(image: ImageProxy) {
                                        var bitmap: Bitmap? = null
                                        var failure: String? = null
                                        try {
                                            bitmap = imageProxyToBitmap(image)
                                        } catch (e: Exception) {
                                            failure = e.message ?: "Could not decode captured photo. Please retry."
                                        } catch (e: OutOfMemoryError) {
                                            failure = "This photo used too much memory. Please retry or use a smaller photo."
                                        } finally {
                                            runCatching { image.close() }
                                        }
                                        ContextCompat.getMainExecutor(context).execute {
                                            val ready = bitmap
                                            if (ready != null) onImageCaptured(ready)
                                            else onCaptureError(failure ?: "Photo capture failed. Please try again.")
                                        }
                                    }

                                    override fun onError(exception: ImageCaptureException) {
                                        ContextCompat.getMainExecutor(context).execute {
                                            onCaptureError(exception.message ?: "Camera capture failed. Please try again.")
                                        }
                                    }
                                }
                            )
                        }
                        .semantics { contentDescription = "Take photo and identify" }
                )

                // Placeholder for layout balance
                Box(modifier = Modifier.size(48.dp))
            }
        }
    }
}

/**
 * Converts ImageCapture's ImageProxy to a correctly-rotated Bitmap.
 */
private fun imageProxyToBitmap(image: ImageProxy): Bitmap {
    if (image.format != ImageFormat.JPEG) {
        throw IllegalArgumentException("Camera returned an unsupported image format (${image.format}); expected JPEG.")
    }
    val plane = image.planes.firstOrNull()
        ?: throw IllegalArgumentException("Camera returned no image data.")
    val buffer = plane.buffer.duplicate()
    val bytes = ByteArray(buffer.remaining())
    buffer.get(bytes)
    if (bytes.isEmpty()) throw IllegalArgumentException("Camera returned an empty photo.")

    // Decode a bounded bitmap first. The previous implementation decoded the full-resolution
    // image and then rotated another full copy, which could exhaust RAM on high-resolution phones.
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
        throw IllegalArgumentException("The camera photo could not be decoded.")
    }
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > MAX_CAPTURE_DIMENSION) {
        sample *= 2
    }
    val options = BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
        ?: throw IllegalArgumentException("The camera returned an invalid JPEG photo.")

    val rotation = image.imageInfo.rotationDegrees
    if (rotation == 0) return decoded
    val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
    return try {
        Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true).also { rotated ->
            if (rotated !== decoded && !decoded.isRecycled) decoded.recycle()
        }
    } catch (e: Exception) {
        if (!decoded.isRecycled) decoded.recycle()
        throw e
    } catch (e: OutOfMemoryError) {
        if (!decoded.isRecycled) decoded.recycle()
        throw e
    }
}

private const val MAX_CAPTURE_DIMENSION = 1280
