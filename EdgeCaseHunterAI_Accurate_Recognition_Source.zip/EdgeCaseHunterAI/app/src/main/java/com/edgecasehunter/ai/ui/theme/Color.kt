package com.edgecasehunter.ai.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Design Tokens for EdgeCase Hunter AI
 * Sourced directly from DESIGN_TOKENS.json
 */
object AppColors {
    // Primary brand palette
    val Primary = Color(0xFF315EDB)
    val PrimaryPressed = Color(0xFF244EC6)
    val PrimarySubtle = Color(0xFFEAF0FF)

    // Neutral & Surface background palette
    val Background = Color(0xFFF4F7FC)
    val Surface = Color(0xFFFFFFFF)
    val SurfaceSubtle = Color(0xFFF7F9FD)
    val Border = Color(0xFFE5EBF4)

    // Text hierarchy
    val TextPrimary = Color(0xFF17253A)
    val TextSecondary = Color(0xFF68788F)
    val TextMuted = Color(0xFF8A98AD)

    // Semantic status colors
    val Success = Color(0xFF16836D)
    val SuccessSubtle = Color(0xFFE7F7F0)
    val Warning = Color(0xFF9C6414)
    val WarningSubtle = Color(0xFFFFF5DF)
    val Error = Color(0xFFC34848)
    val ErrorSubtle = Color(0xFFFEECEB)

    // Camera & overlay
    val CameraOverlay = Color(0xCC101B2B)
    val CameraScrim = Color(0x66000000)
}
