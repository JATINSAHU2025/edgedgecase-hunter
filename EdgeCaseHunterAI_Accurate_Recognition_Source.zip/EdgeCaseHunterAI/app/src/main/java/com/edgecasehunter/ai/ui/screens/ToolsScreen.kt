package com.edgecasehunter.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ManageSearch
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.edgecasehunter.ai.ui.camera.ScanMode
import com.edgecasehunter.ai.ui.components.ToolCard
import com.edgecasehunter.ai.ui.theme.AppColors

/**
 * 06 — Tools Screen
 * Vision and AI analysis utilities running locally or with transparent online status.
 */
@Composable
fun ToolsScreen(
    onLaunchScanMode: (ScanMode) -> Unit,
    modifier: Modifier = Modifier
) {
    var toolInfoDialogTitle by remember { mutableStateOf<String?>(null) }
    var toolInfoDialogMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AppColors.Background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = "Vision & AI Tools",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = AppColors.TextPrimary
            )
            Text(
                text = "Specialized computer vision utilities running locally on your device",
                fontSize = 13.sp,
                color = AppColors.TextSecondary
            )
        }

        // Tool 1: Text Recognition (OCR)
        ToolCard(
            title = "Text Recognition (OCR)",
            description = "Extract printed text, signs, document lines and labels directly on device without internet.",
            icon = Icons.Default.TextFields,
            isOffline = true,
            onClick = { onLaunchScanMode(ScanMode.TEXT) }
        )

        // Tool 2: Barcode & QR Scanner
        ToolCard(
            title = "Barcode & QR Scanner",
            description = "Fast real-time decoder for UPC, EAN-13, QR codes, Code 128 and Data Matrix.",
            icon = Icons.Default.QrCodeScanner,
            isOffline = true,
            onClick = { onLaunchScanMode(ScanMode.BARCODE) }
        )

        // Tool 3: Multi-Object Inspector
        ToolCard(
            title = "Multi-Object Inspector",
            description = "Analyze complex scenes with multiple objects and isolate individual candidate crops.",
            icon = Icons.Default.SelectAll,
            isOffline = true,
            onClick = { onLaunchScanMode(ScanMode.MULTI) }
        )

        // Tool 4: Photo Comparison
        ToolCard(
            title = "Photo Comparison",
            description = "Compare two images side-by-side to verify visual features and label similarity.",
            icon = Icons.Default.Compare,
            isOffline = true,
            onClick = {
                toolInfoDialogTitle = "Photo Comparison Tool"
                toolInfoDialogMessage = "Photo comparison lets you test two photos against on-device classification models to inspect invariant features and prediction stability. Select an image from Scan to begin."
            }
        )

        // Tool 5: Visual Search (Online)
        ToolCard(
            title = "Reverse Visual Search",
            description = "Find matching products and visual web references. Requires an external provider backend.",
            icon = Icons.AutoMirrored.Filled.ManageSearch,
            isOffline = false,
            onClick = {
                toolInfoDialogTitle = "Online Visual Search"
                toolInfoDialogMessage = "Online visual search requires a secure configured backend server. To protect privacy and adhere to our zero-data-leakage policy, online search is kept disabled until custom server credentials are provided."
            }
        )

        // Tool 6: Ask EdgeCase AI (Multimodal Assistant)
        ToolCard(
            title = "Ask EdgeCase AI",
            description = "Ask conversational follow-up questions about detected objects and their visual properties.",
            icon = Icons.Default.AutoAwesome,
            isOffline = false,
            onClick = {
                toolInfoDialogTitle = "Multimodal Assistant"
                toolInfoDialogMessage = "Follow-up multimodal reasoning requires a secure vision-language model endpoint. No third-party API keys are embedded inside this APK to preserve security. Use the on-device analyzer for immediate local results."
            }
        )

        Spacer(modifier = Modifier.height(60.dp))
    }

    if (toolInfoDialogTitle != null && toolInfoDialogMessage != null) {
        AlertDialog(
            onDismissRequest = {
                toolInfoDialogTitle = null
                toolInfoDialogMessage = null
            },
            title = { Text(toolInfoDialogTitle!!) },
            text = { Text(toolInfoDialogMessage!!) },
            confirmButton = {
                TextButton(
                    onClick = {
                        toolInfoDialogTitle = null
                        toolInfoDialogMessage = null
                    }
                ) {
                    Text("Understood", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
