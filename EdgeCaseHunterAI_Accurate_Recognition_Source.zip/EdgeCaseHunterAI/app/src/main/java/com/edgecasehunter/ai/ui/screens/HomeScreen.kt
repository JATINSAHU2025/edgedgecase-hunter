package com.edgecasehunter.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.edgecasehunter.ai.BuildConfig
import com.edgecasehunter.ai.data.SavedScan
import com.edgecasehunter.ai.ui.camera.ScanMode
import com.edgecasehunter.ai.ui.components.AppSearchField
import com.edgecasehunter.ai.ui.components.EmptyStateView
import com.edgecasehunter.ai.ui.components.HeroIdentifyCard
import com.edgecasehunter.ai.ui.components.ScanRowCard
import com.edgecasehunter.ai.ui.components.SectionHeader
import com.edgecasehunter.ai.ui.components.ShortcutCard
import com.edgecasehunter.ai.ui.components.StatusBadge
import com.edgecasehunter.ai.ui.theme.AppColors

/**
 * 01 — Home Dashboard
 * Primary entry with hero scan CTA, quick shortcuts, runtime status, and recent scans.
 */
@Composable
fun HomeScreen(
    savedScans: List<SavedScan>,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onOpenScan: (ScanMode) -> Unit,
    onOpenScanDetail: (SavedScan) -> Unit,
    onViewAllLibrary: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AppColors.Background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(AppColors.Primary, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CenterFocusStrong,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = "EdgeCase Hunter AI",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = AppColors.TextPrimary
                    )
                    Text(
                        text = "Visual Identification Assistant",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = AppColors.TextSecondary
                    )
                }
            }

            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.semantics { contentDescription = "Open app settings and model attribution" }
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = null,
                    tint = AppColors.TextSecondary
                )
            }
        }

        // Search Field
        AppSearchField(
            query = searchQuery,
            onQueryChange = onSearchChange,
            placeholder = "Search objects, categories, tools..."
        )

        // Hero Card
        HeroIdentifyCard(
            onScanClick = { onOpenScan(ScanMode.PHOTO) }
        )

        // Three Quick Shortcuts
        SectionHeader(title = "Quick Actions")
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ShortcutCard(
                title = "Read text",
                subtitle = "OCR reader",
                icon = Icons.Default.TextFields,
                onClick = { onOpenScan(ScanMode.TEXT) },
                modifier = Modifier.weight(1f)
            )

            ShortcutCard(
                title = "Scan code",
                subtitle = "Barcode & QR",
                icon = Icons.Default.QrCodeScanner,
                onClick = { onOpenScan(ScanMode.BARCODE) },
                modifier = Modifier.weight(1f)
            )

            ShortcutCard(
                title = "Multi-object",
                subtitle = "Detect scenes",
                icon = Icons.Default.CenterFocusStrong,
                onClick = { onOpenScan(ScanMode.MULTI) },
                modifier = Modifier.weight(1f)
            )
        }

        // Model & Runtime Status Banner
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = AppColors.Surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, AppColors.Border),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(AppColors.SuccessSubtle, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = AppColors.Success,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Engine Ready",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = AppColors.TextPrimary
                        )
                        StatusBadge(
                            text = "OFFLINE",
                            textColor = AppColors.Success,
                            backgroundColor = AppColors.SuccessSubtle
                        )
                    }
                    Text(
                        text = "${BuildConfig.MODEL_DISPLAY_NAME} is active. Inference runs locally on device.",
                        fontSize = 11.sp,
                        color = AppColors.TextSecondary,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // Recent Scans Section
        SectionHeader(
            title = "Recent Scans",
            actionText = if (savedScans.isNotEmpty()) "View All" else null,
            onActionClick = onViewAllLibrary
        )

        if (savedScans.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.BookmarkBorder,
                title = "No recent scans saved",
                message = "Scans you choose to save will appear here. Tap the camera button below to start identifying objects.",
                actionText = "Start Scan",
                onActionClick = { onOpenScan(ScanMode.PHOTO) }
            )
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                savedScans.take(3).forEach { scan ->
                    ScanRowCard(
                        scan = scan,
                        onClick = { onOpenScanDetail(scan) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(60.dp))
    }
}
