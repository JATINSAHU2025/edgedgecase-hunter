package com.edgecasehunter.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.edgecasehunter.ai.ui.ClassifierRoute
import com.edgecasehunter.ai.ui.theme.EdgeCaseHunterTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EdgeCaseHunterTheme {
                ClassifierRoute()
            }
        }
    }
}
