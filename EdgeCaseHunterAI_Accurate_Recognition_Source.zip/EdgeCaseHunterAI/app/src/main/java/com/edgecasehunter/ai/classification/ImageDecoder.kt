package com.edgecasehunter.ai.classification

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayInputStream
import java.nio.ByteBuffer

object SelectedImageDecoder {
    private const val MAX_DECODE_DIMENSION = 1280
    private const val MAX_COMPRESSED_BYTES = 12 * 1024 * 1024

    fun decode(context: Context, uri: Uri): Bitmap {
        val bytes = try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(16 * 1024)
                var total = 0
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > MAX_COMPRESSED_BYTES) {
                        throw ClassifierException.UnsupportedImage("Selected image exceeds the 12 MB import limit.")
                    }
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            } ?: throw ClassifierException.UnsupportedImage("Unable to read the selected image.")
        } catch (e: ClassifierException) {
            throw e
        } catch (e: OutOfMemoryError) {
            throw ClassifierException.UnsupportedImage("Not enough memory to read this image. Try a smaller photo.", e)
        } catch (e: Exception) {
            throw ClassifierException.UnsupportedImage("Unable to read the selected image: ${e.message ?: "unknown error"}", e)
        }
        return decodeBytes(bytes)
    }

    fun decodeBytes(bytes: ByteArray): Bitmap {
        ImageBytes.validateHeader(bytes)
        return try {
            val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val source = ImageDecoder.createSource(ByteBuffer.wrap(bytes))
                ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val longest = maxOf(info.size.width, info.size.height)
                    if (longest > MAX_DECODE_DIMENSION) {
                        val scale = longest / MAX_DECODE_DIMENSION
                        decoder.setTargetSampleSize(maxOf(1, scale))
                    }
                }
            } else {
                decodeLegacy(bytes)
            }
            val software = bitmap.copy(Bitmap.Config.ARGB_8888, false)
                ?: throw ClassifierException.UnsupportedImage("Could not convert this image into a format supported by the classifier.")
            if (software !== bitmap) bitmap.recycle()
            if (software.width <= 0 || software.height <= 0) {
                software.recycle()
                throw ClassifierException.UnsupportedImage("Decoded image has invalid dimensions.")
            }
            software
        } catch (e: ClassifierException) {
            throw e
        } catch (e: OutOfMemoryError) {
            throw ClassifierException.UnsupportedImage("The image is too large to decode on this device.", e)
        } catch (e: Exception) {
            throw ClassifierException.UnsupportedImage("The image could not be decoded. It may be corrupt.", e)
        }
    }

    private fun decodeLegacy(bytes: ByteArray): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw ClassifierException.UnsupportedImage("The image header is invalid.")
        }
        val longest = maxOf(bounds.outWidth, bounds.outHeight)
        var sample = 1
        while (longest / sample > MAX_DECODE_DIMENSION) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
            ?: throw ClassifierException.UnsupportedImage("BitmapFactory returned no image.")
        return applyExif(bytes, decoded)
    }

    private fun applyExif(bytes: ByteArray, bitmap: Bitmap): Bitmap {
        val exif = ExifInterface(ByteArrayInputStream(bytes))
        val orientation = exif.getAttributeInt(
            ExifInterface.TAG_ORIENTATION,
            ExifInterface.ORIENTATION_NORMAL
        )
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            else -> return bitmap
        }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        if (rotated !== bitmap) {
            bitmap.recycle()
        }
        return rotated
    }
}
