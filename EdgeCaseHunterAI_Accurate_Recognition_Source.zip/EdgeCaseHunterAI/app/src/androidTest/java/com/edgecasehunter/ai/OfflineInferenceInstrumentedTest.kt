package com.edgecasehunter.ai

import android.graphics.Bitmap
import android.graphics.Color
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.edgecasehunter.ai.classification.ClassifierException
import com.edgecasehunter.ai.classification.ImageBytes
import com.edgecasehunter.ai.classification.OfflineImageClassifier
import com.edgecasehunter.ai.classification.ResultSource
import com.edgecasehunter.ai.classification.SelectedImageDecoder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class OfflineInferenceInstrumentedTest {

    @Test
    fun realModel_returnsFiveFiniteScores() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        OfflineImageClassifier(context).use { classifier ->
            val bitmap = Bitmap.createBitmap(224, 224, Bitmap.Config.ARGB_8888)
            bitmap.eraseColor(Color.rgb(200, 30, 30))
            val result = classifier.classify(bitmap)
            bitmap.recycle()
            assertEquals(ResultSource.ON_DEVICE, result.source)
            assertEquals(5, result.topPredictions.size)
            assertEquals(1000, result.outputLength)
            assertEquals(BuildConfig.MODEL_REVISION, result.modelRevision)
            result.topPredictions.forEach { prediction ->
                assertTrue(prediction.label.isNotBlank())
                assertTrue(prediction.modelScore.isFinite())
                assertTrue(prediction.index in 0 until 1000)
            }
            assertTrue(result.inferenceTimeMs >= 0)
        }
    }

    @Test
    fun malformedBytes_areRejectedWithoutNetwork() {
        val garbage = "this is not an image".toByteArray()
        try {
            ImageBytes.validateHeader(garbage)
            throw AssertionError("Expected unsupported image")
        } catch (e: ClassifierException.UnsupportedImage) {
            assertTrue(e.message!!.contains("Unsupported") || e.message!!.contains("empty"))
        }
        try {
            SelectedImageDecoder.decodeBytes(byteArrayOf(1, 2, 3, 4, 5, 6))
            throw AssertionError("Expected decode failure")
        } catch (e: ClassifierException.UnsupportedImage) {
            assertTrue(e.message!!.isNotBlank())
        }
    }
}
