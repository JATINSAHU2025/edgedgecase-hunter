package com.edgecasehunter.ai.classification

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import com.edgecasehunter.ai.BuildConfig
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.task.core.BaseOptions
import org.tensorflow.lite.task.vision.classifier.ImageClassifier
import java.io.Closeable

/**
 * On-device classifier using TensorFlow Lite Task Vision ImageClassifier.
 * Preprocessing (RGB, 224x224, quantization) comes from the model's metadata.
 */
class OfflineImageClassifier(
    context: Context
) : Closeable {

    private val appContext = context.applicationContext
    private val labels: List<String> = loadBundledLabels(appContext)
    private val classifier: ImageClassifier = createClassifier(appContext)

    val isReady: Boolean get() = true

    fun classify(bitmap: Bitmap): ClassificationResult {
        if (bitmap.isRecycled) {
            throw ClassifierException.UnsupportedImage("This image has already been released. Please capture or choose it again.")
        }
        if (bitmap.width <= 0 || bitmap.height <= 0) {
            throw ClassifierException.UnsupportedImage("Image has invalid dimensions.")
        }

        var ownedBitmap: Bitmap? = null
        try {
            val argb = if (bitmap.config == Bitmap.Config.ARGB_8888) {
                bitmap
            } else {
                (bitmap.copy(Bitmap.Config.ARGB_8888, false)
                    ?: throw ClassifierException.UnsupportedImage("Could not convert this image for classification.")).also {
                    ownedBitmap = it
                }
            }
            val tensorImage = TensorImage.fromBitmap(argb)
            val start = SystemClock.elapsedRealtime()
            val classifications = classifier.classify(tensorImage)
            val elapsed = SystemClock.elapsedRealtime() - start
            val categories = classifications.firstOrNull()?.categories.orEmpty()
            if (categories.isEmpty()) {
                throw ClassifierException.InferenceFailed("The model returned no class scores.")
            }
            val predictions = categories.mapIndexed { rank, category ->
                val index = category.index
                if (index < 0 || index >= labels.size) {
                    throw ClassifierException.InferenceFailed(
                        "Model output index $index is outside the ${labels.size} ImageNet labels."
                    )
                }
                if (category.score.isNaN() || !category.score.isFinite()) {
                    throw ClassifierException.InferenceFailed("Model score is not a finite number.")
                }
                ScoredLabel(
                    rank = rank + 1,
                    index = index,
                    label = labels[index].ifBlank { category.label },
                    modelScore = category.score
                )
            }.take(BuildConfig.TOP_K)
            ClassificationResult(
                topPredictions = predictions,
                inferenceTimeMs = elapsed,
                source = ResultSource.ON_DEVICE,
                modelName = BuildConfig.MODEL_DISPLAY_NAME,
                modelRevision = BuildConfig.MODEL_REVISION,
                inputWidth = BuildConfig.MODEL_INPUT_SIZE,
                inputHeight = BuildConfig.MODEL_INPUT_SIZE,
                outputLength = labels.size
            )
        } catch (e: ClassifierException) {
            throw e
        } catch (e: OutOfMemoryError) {
            throw ClassifierException.InferenceFailed("Not enough memory to run inference. Try a smaller or closer photo.", e)
        } catch (e: Exception) {
            throw ClassifierException.InferenceFailed("On-device inference failed: ${e.message ?: "unknown error"}", e)
        } finally {
            ownedBitmap?.takeIf { !it.isRecycled }?.recycle()
        }
    }

    override fun close() {
        classifier.close()
    }

    companion object {
        private fun createClassifier(context: Context): ImageClassifier {
            return try {
                val options = ImageClassifier.ImageClassifierOptions.builder()
                    .setBaseOptions(
                        BaseOptions.builder()
                            .setNumThreads(4)
                            .build()
                    )
                    .setMaxResults(BuildConfig.TOP_K)
                    .build()
                ImageClassifier.createFromFileAndOptions(
                    context,
                    BuildConfig.MODEL_ASSET_NAME,
                    options
                )
            } catch (e: Exception) {
                throw ClassifierException.ModelLoadFailed(
                    "Failed to load ${BuildConfig.MODEL_DISPLAY_NAME} from app assets.",
                    e
                )
            }
        }

        fun loadBundledLabels(context: Context): List<String> {
            val text = context.assets.open("labels/imagenet_labels.txt").bufferedReader().use { it.readText() }
            val labels = LabelMapper.loadLabels(text)
            require(labels.size == 1000) {
                "Expected 1000 ImageNet-1K labels, found ${labels.size}"
            }
            return labels
        }
    }
}
